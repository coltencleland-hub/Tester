# Chaos Lab — build handoff

Status: all seven native Kotlin/Compose experiment modules are implemented. This project has **not been compiled or tested on an Android device**. No APK has been generated. The original environment had no Android SDK or Gradle, and dependency downloads could not execute.

## Build on your computer

1. Install Android Studio and its Android SDK. In SDK Manager install Android SDK Platform 35 and Android SDK Build-Tools 35.0.0.
2. Install Gradle **8.9** and use JDK **17** (Android Studio’s embedded JDK 21 also works with Gradle 8.9). Download Gradle from https://gradle.org/releases/ if needed.
3. Extract this folder. Create `local.properties` in this folder containing `sdk.dir=/absolute/path/to/your/Android/sdk`. On Windows, use forward slashes, for example `sdk.dir=C:/Users/you/AppData/Local/Android/Sdk`.
4. From this folder run:

```sh
gradle --version
gradle :app:assembleDebug --stacktrace
```

The first build needs internet access to Google Maven, Maven Central and the Gradle plugin repositories. Compiler errors may still need correction; capture the full build output if you want help resolving them.

After a successful build the debug APK is:

```
app/build/outputs/apk/debug/app-debug.apk
```

There is no generated Gradle wrapper in this handoff because Gradle could not be installed here. Once Gradle works, create the standard wrapper with:

```sh
gradle wrapper --gradle-version 8.9 --distribution-type bin
```

You can then open the folder in Android Studio and use `./gradlew :app:assembleDebug` (Windows: `gradlew.bat :app:assembleDebug`).

## Try on a device

Requires Android 8.0 (API 26) or later. Copy the APK to your phone and open it, or enable USB debugging and run `adb install -r app/build/outputs/apk/debug/app-debug.apk`. Test on a physical phone to exercise the microphone, camera, accelerometer, gyroscope, compass and vibration.

Microphone and camera permissions are requested only when their experiments open. Tap the Chaos Lab title seven times to open the developer menu. Settings includes FPS overlay and quality controls.

## Implementation

Native Compose navigation/theme, physics circle collision simulation with tilt and drawn obstacles, fire/water/smoke/sparks with gravity wells, real microphone PCM plus FFT, CameraX with actual pixel effects, real sensor graphs and projected phone, 12 procedural art algorithms, randomized Chaos Button effects with physics/sound/haptics, persisted settings and live performance/developer controls. All graphics are generated in code.

## Build using only your Android phone

The included `.github/workflows/build-apk.yml` builds on GitHub's Ubuntu servers and requires no desktop computer or local Android SDK. It is not yet tested; a build may expose compiler errors that still need fixes.

1. Create a GitHub repository (private is fine within your Actions allowance).
2. Upload the contents of the extracted ChaosLab folder so `settings.gradle.kts`, `app/`, and `.github/` are at the repository root. Preserve directories and include the hidden `.github` folder. If the mobile browser cannot upload directories, use a Git client on Android or Termux with git; install Termux from F-Droid or its official GitHub releases.
3. On GitHub open Actions, select Build Chaos Lab APK, and Run workflow. Push to main/master also starts it.
4. After a successful run, download the Chaos-Lab-debug-APK artifact from the run page. Extract the artifact ZIP and install app-debug.apk on Android 8 or newer.
5. If it fails, download the Chaos-Lab-build-log artifact or copy the Build debug APK step's error output for debugging.

Do not upload the outer ChaosLab directory as an extra nested folder: the workflow expects Gradle build files at the repository root. Merely uploading the source ZIP to GitHub is insufficient; upload its extracted contents.
