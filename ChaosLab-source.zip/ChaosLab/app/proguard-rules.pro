# Compose and CameraX consumer rules are supplied by their dependencies.
