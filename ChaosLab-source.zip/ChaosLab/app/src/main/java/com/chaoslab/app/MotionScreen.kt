package com.chaoslab.app

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private class SensorTrace {
    val x = FloatArray(180)
    val y = FloatArray(180)
    val z = FloatArray(180)
    var head = 0
    var filled = 0
    fun add(value: SensorVector) {
        x[head] = value.x; y[head] = value.y; z[head] = value.z
        head = (head + 1) % x.size
        filled = min(filled + 1, x.size)
    }
    fun clear() { head = 0; filled = 0 }
}

@Composable
fun MotionScreen(app: AppState) {
    val sensors = rememberLabSensors()
    var selected by remember { mutableIntStateOf(0) }
    var frozen by remember { mutableStateOf(false) }
    var range by remember { mutableFloatStateOf(1f) }
    val trace = remember { SensorTrace() }
    var frame by remember { mutableIntStateOf(0) }
    var pitch by remember { mutableFloatStateOf(0f) }
    var roll by remember { mutableFloatStateOf(0f) }
    var heading by remember { mutableFloatStateOf(0f) }
    var accumulator by remember { mutableFloatStateOf(0f) }
    val vector = when (selected) { 0 -> sensors.acceleration; 1 -> sensors.gyroscope; else -> sensors.magnetic }
    val unit = when (selected) { 0 -> "m/s²"; 1 -> "rad/s"; else -> "µT" }
    val available = when (selected) { 0 -> sensors.hasAccelerometer; 1 -> sensors.hasGyroscope; else -> sensors.hasMagnetometer }
    val scale = when (selected) { 0 -> 20f; 1 -> 6f; else -> 100f } * range
    SimulationLoop { dt ->
        val smoothing = min(1f, dt * (if (app.reducedMotion) 4f else 12f))
        pitch += (sensors.orientation.pitch - pitch) * smoothing
        roll += (((sensors.orientation.roll - roll + 540f) % 360f) - 180f) * smoothing
        heading += (((sensors.orientation.azimuth - heading + 540f) % 360f) - 180f) * smoothing
        accumulator += dt
        if (!frozen && accumulator >= 1f / 30f && available && sensors.active) {
            accumulator %= 1f / 30f
            trace.add(vector)
        }
        frame++
        app.activeObjects = trace.filled
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SensorAvailability("ACCEL", sensors.hasAccelerometer, Modifier.weight(1f))
            SensorAvailability("GYRO", sensors.hasGyroscope, Modifier.weight(1f))
            SensorAvailability("COMPASS", sensors.hasOrientation, Modifier.weight(1f))
        }
        LabSurface(Modifier.fillMaxWidth().height(maxOf(190.dp, maxHeight - 300.dp))) {
            Canvas(Modifier.fillMaxSize()) {
                @Suppress("UNUSED_VARIABLE") val drawFrame = frame
                val w = size.width
                val h = size.height
                val upper = h * 0.49f
                val faint = LabColors.cyan.copy(alpha = 0.06f)
                for (i in 0..8) drawLine(faint, Offset(0f, upper * i / 8), Offset(w, upper * i / 8), 1f)
                for (i in 0..10) drawLine(faint, Offset(w * i / 10, 0f), Offset(w * i / 10, upper), 1f)
                drawPhoneOrientation(Offset(w * .29f, upper * .51f), min(w * .20f, upper * .26f), pitch, roll, heading)
                drawCompass(Offset(w * .76f, upper * .50f), min(w * .19f, upper * .35f), heading)
                drawLabel(if (sensors.hasOrientation) "DEVICE ORIENTATION" else "ORIENTATION UNAVAILABLE", Offset(16.dp.toPx(), 20.dp.toPx()), LabColors.muted, 10.sp.toPx())
                drawLabel("MAGNETIC NORTH", Offset(w * .57f, upper - 10.dp.toPx()), LabColors.muted, 9.sp.toPx())
                val left = 16.dp.toPx()
                val right = w - 16.dp.toPx()
                val top = upper + 22.dp.toPx()
                val bottom = h - 23.dp.toPx()
                val middle = (top + bottom) / 2
                val amplitude = max(10f, (bottom - top) / 2)
                for (i in 0..4) {
                    val y = top + (bottom - top) * i / 4
                    drawLine(LabColors.muted.copy(alpha = if (i == 2) .32f else .12f), Offset(left, y), Offset(right, y), 1f)
                }
                drawLabel("+${formatSensor(scale)} $unit", Offset(left, top - 5.dp.toPx()), LabColors.muted, 9.sp.toPx())
                drawLabel("−${formatSensor(scale)}", Offset(left, h - 8.dp.toPx()), LabColors.muted, 9.sp.toPx())
                listOf(trace.x to LabColors.cyan, trace.y to LabColors.pink, trace.z to LabColors.amber).forEach { (samples, color) ->
                    if (trace.filled > 1) {
                        val path = Path()
                        for (i in 0 until trace.filled) {
                            val index = (trace.head - trace.filled + i + samples.size) % samples.size
                            val x = right - (trace.filled - 1 - i) * (right - left) / (samples.size - 1)
                            val y = middle - (samples[index] / scale).coerceIn(-1f, 1f) * amplitude
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        drawPath(path, color.copy(alpha = .10f), style = Stroke(8.dp.toPx()))
                        drawPath(path, color, style = Stroke(1.6.dp.toPx()))
                    }
                }
                if (!available) drawLabel("This device has no ${if (selected == 0) "accelerometer" else if (selected == 1) "gyroscope" else "magnetometer"}.", Offset(left, middle), LabColors.text, 12.sp.toPx())
                else if (!sensors.active) drawLabel("Sensor stream paused", Offset(left, middle), LabColors.muted, 12.sp.toPx())
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("YAW ${if (sensors.orientationTimestampNanos > 0) "${formatSensor(sensors.orientation.azimuth)}°" else "—"}", color = LabColors.cyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("PITCH ${if (sensors.orientationTimestampNanos > 0) "${formatSensor(sensors.orientation.pitch)}°" else "—"}", color = LabColors.purple, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("ROLL ${if (sensors.orientationTimestampNanos > 0) "${formatSensor(sensors.orientation.roll)}°" else "—"}", color = LabColors.pink, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        ControlPanel {
            ChoiceChips(listOf("Acceleration", "Gyroscope", "Magnetic"), selected) { selected = it; trace.clear(); frame++ }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("X" to (vector.x to LabColors.cyan), "Y" to (vector.y to LabColors.pink), "Z" to (vector.z to LabColors.amber)).forEach { (axis, data) ->
                    Text("$axis ${if (available) formatSensor(data.first) else "—"} $unit", color = data.second, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
            LabSlider("Graph range ×${formatSensor(range)}", range, { range = it }, .2f..3f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("30 Hz trace · 6 seconds", color = LabColors.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp))
                OutlinedButton(onClick = { frozen = !frozen }) { Text(if (frozen) "Resume graph" else "Freeze graph") }
            }
            Text("Compass readings can drift near magnets. Move the phone in a figure eight to calibrate.", color = LabColors.muted, fontSize = 10.sp)
        }
    }
    }
}

@Composable
private fun SensorAvailability(label: String, present: Boolean, modifier: Modifier) {
    LabSurface(modifier) {
        Text("${if (present) "●" else "○"} $label", color = if (present) LabColors.cyan else LabColors.muted,
            fontSize = 9.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp))
    }
}

private fun formatSensor(value: Float) = String.format(Locale.US, "%.1f", value)

private fun DrawScope.drawLabel(text: String, point: Offset, color: Color, fontSize: Float) {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color.toArgb()
        textSize = fontSize
        typeface = android.graphics.Typeface.create("monospace", android.graphics.Typeface.NORMAL)
    }
    drawContext.canvas.nativeCanvas.drawText(text, point.x, point.y, paint)
}

private fun DrawScope.drawCompass(center: Offset, radius: Float, heading: Float) {
    drawCircle(LabColors.cyan.copy(alpha = .05f), radius, center)
    drawCircle(LabColors.cyan.copy(alpha = .24f), radius, center, style = Stroke(1.dp.toPx()))
    for (i in 0 until 36) {
        val angle = (i * 10f - 90f) * (Math.PI / 180f).toFloat()
        val longTick = i % 9 == 0
        val inner = radius * if (longTick) .80f else .91f
        drawLine(LabColors.muted.copy(alpha = if (longTick) .75f else .3f),
            center + Offset(cos(angle) * inner, sin(angle) * inner),
            center + Offset(cos(angle) * radius, sin(angle) * radius), if (longTick) 2.dp.toPx() else 1.dp.toPx())
    }
    val angle = (-heading - 90f) * (Math.PI / 180f).toFloat()
    val tip = center + Offset(cos(angle), sin(angle)) * (radius * .73f)
    val tail = center - Offset(cos(angle), sin(angle)) * (radius * .62f)
    val side = Offset(-sin(angle), cos(angle)) * (radius * .12f)
    drawPath(Path().apply { moveTo(tip.x, tip.y); lineTo((center + side).x, (center + side).y); lineTo((center - side).x, (center - side).y); close() }, LabColors.pink)
    drawPath(Path().apply { moveTo(tail.x, tail.y); lineTo((center + side).x, (center + side).y); lineTo((center - side).x, (center - side).y); close() }, LabColors.cyan.copy(alpha = .6f))
    drawCircle(LabColors.text, 3.dp.toPx(), center)
    drawLabel("N", Offset(center.x - 4.dp.toPx(), center.y - radius - 6.dp.toPx()), LabColors.pink, 11.sp.toPx())
    drawLabel("${((heading % 360f + 360f) % 360f).toInt()}°", Offset(center.x - 15.dp.toPx(), center.y + radius + 18.dp.toPx()), LabColors.text, 11.sp.toPx())
}

private fun DrawScope.drawPhoneOrientation(center: Offset, scale: Float, pitch: Float, roll: Float, heading: Float) {
    val radians = (Math.PI / 180f).toFloat()
    val p = pitch * radians
    val r = roll * radians
    val y = heading * radians
    fun project(x: Float, vertical: Float, z: Float): Offset {
        val py = vertical * cos(p) - z * sin(p)
        val pz = vertical * sin(p) + z * cos(p)
        val rx = x * cos(r) + pz * sin(r)
        val rz = -x * sin(r) + pz * cos(r)
        val xx = rx * cos(y) - py * sin(y)
        val yy = rx * sin(y) + py * cos(y)
        val perspective = 3.5f / (3.5f + rz)
        return center + Offset(xx, yy) * scale * perspective
    }
    val front = listOf(project(-.64f, -1.2f, -.10f), project(.64f, -1.2f, -.10f), project(.64f, 1.2f, -.10f), project(-.64f, 1.2f, -.10f))
    val back = listOf(project(-.64f, -1.2f, .10f), project(.64f, -1.2f, .10f), project(.64f, 1.2f, .10f), project(-.64f, 1.2f, .10f))
    fun polygon(points: List<Offset>) = Path().apply {
        moveTo(points[0].x, points[0].y)
        points.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }
    drawCircle(LabColors.purple.copy(alpha = .06f), scale * 1.8f, center)
    drawPath(polygon(back), LabColors.purple.copy(alpha = .18f))
    for (i in 0..3) drawLine(LabColors.purple, back[i], front[i], 2.dp.toPx())
    drawPath(polygon(front), LabColors.panel.copy(alpha = .96f))
    drawPath(polygon(front), LabColors.cyan, style = Stroke(2.dp.toPx()))
    for (i in 0..5) drawLine(LabColors.cyan.copy(alpha = .24f), project(-.50f, -.75f + i * .31f, -.11f), project(.5f, -.75f + i * .31f, -.11f), 1.dp.toPx())
    drawLine(LabColors.pink, project(-.19f, -1.03f, -.11f), project(.19f, -1.03f, -.11f), 3.dp.toPx())
    drawCircle(LabColors.cyan, 2.8.dp.toPx(), project(0f, 1.0f, -.11f))
}
