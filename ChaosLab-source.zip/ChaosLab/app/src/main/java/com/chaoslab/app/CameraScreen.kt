package com.chaoslab.app

import android.Manifest
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Camera effects run on actual YUV frames, never on a decorative preview overlay. */
@Composable
fun CameraScreen(app: AppState) {
    PermissionGate(
        Manifest.permission.CAMERA,
        "Open the camera",
        "Camera FX processes the live camera feed on your device. Tap the viewfinder to focus."
    ) {
        CameraLab(app)
    }
}

@Composable
private fun CameraLab(app: AppState) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember(context) {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }
    val filters = remember { listOf("Natural", "Mono", "Neon edges", "Thermal", "Pixel art", "Negative", "Posterize", "RGB drift") }
    var filter by remember { mutableIntStateOf(0) }
    var intensity by remember { mutableFloatStateOf(0.8f) }
    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var canFlip by remember { mutableStateOf(false) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var torch by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var connecting by remember { mutableStateOf(true) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var captureFps by remember { mutableFloatStateOf(0f) }
    var processingMs by remember { mutableFloatStateOf(0f) }
    var frameSize by remember { mutableStateOf("") }
    var focusPoint by remember { mutableStateOf<Offset?>(null) }
    val filterRef = remember { AtomicInteger(0) }
    val intensityRef = remember { AtomicInteger(80) }
    val qualityRef = remember { AtomicInteger(80) }

    SideEffect {
        filterRef.set(filter)
        intensityRef.set((intensity * 100).toInt())
        qualityRef.set((app.quality * 100).toInt())
        app.activeObjects = 0
    }

    DisposableEffect(context, lifecycleOwner, lens) {
        val disposed = AtomicBoolean(false)
        val executor = Executors.newSingleThreadExecutor()
        val handler = Handler(Looper.getMainLooper())
        val processor = CameraFrameProcessor()
        var provider: ProcessCameraProvider? = null
        var boundPreview: Preview? = null
        var boundAnalysis: ImageAnalysis? = null
        connecting = true
        error = null
        bitmap = null
        camera = null
        torch = false
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (!disposed.get()) {
                try {
                    val available = future.get()
                    provider = available
                    val back = available.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)
                    val front = available.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
                    canFlip = back && front
                    val selector = if (lens == CameraSelector.LENS_FACING_FRONT && front) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else if (back) {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    } else if (front) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        throw IllegalStateException("This device has no available camera.")
                    }
                    val mirror = selector == CameraSelector.DEFAULT_FRONT_CAMERA
                    val rotation = previewView.display?.rotation ?: Surface.ROTATION_0
                    val preview = Preview.Builder().setTargetRotation(rotation).build()
                    preview.setSurfaceProvider(previewView.surfaceProvider)
                    val analysis = ImageAnalysis.Builder()
                        .setTargetResolution(Size(640, 480))
                        .setTargetRotation(rotation)
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                    boundPreview = preview
                    boundAnalysis = analysis
                    var previousFrame = 0L
                    var lastOutput = 0L
                    var smoothedFps = 0f
                    analysis.setAnalyzer(executor) { image ->
                        try {
                            if (!disposed.get()) {
                                val now = SystemClock.elapsedRealtimeNanos()
                                if (previousFrame != 0L) {
                                    val instantaneous = 1_000_000_000f / (now - previousFrame).coerceAtLeast(1)
                                    smoothedFps = if (smoothedFps == 0f) instantaneous else smoothedFps * .9f + instantaneous * .1f
                                }
                                previousFrame = now
                                // Keep camera acquisition at hardware speed while bounding CPU effects to 30 Hz.
                                if (now - lastOutput >= 30_000_000L) {
                                    lastOutput = now
                                    val selected = filterRef.get()
                                    val start = SystemClock.elapsedRealtimeNanos()
                                    val result = if (selected == 0) null else processor.process(
                                        image, selected, intensityRef.get() / 100f,
                                        qualityRef.get() / 100f, mirror
                                    )
                                    val duration = (SystemClock.elapsedRealtimeNanos() - start) / 1_000_000f
                                    val fps = smoothedFps
                                    val resolution = if (result != null) "${result.width} × ${result.height}" else "${image.width} × ${image.height}"
                                    handler.post {
                                        if (!disposed.get()) {
                                            if (selected == filterRef.get()) bitmap = result
                                            captureFps = fps
                                            processingMs = duration
                                            frameSize = resolution
                                            connecting = false
                                        }
                                    }
                                }
                            }
                        } catch (failure: Exception) {
                            handler.post {
                                if (!disposed.get()) error = "Frame processing failed: ${failure.message ?: failure.javaClass.simpleName}"
                            }
                        } finally {
                            image.close()
                        }
                    }
                    camera = available.bindToLifecycle(lifecycleOwner, selector, preview, analysis)
                } catch (failure: Exception) {
                    connecting = false
                    error = failure.message ?: "The camera is busy or unavailable."
                }
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            disposed.set(true)
            boundAnalysis?.clearAnalyzer()
            val useCases = listOfNotNull(boundPreview, boundAnalysis)
            if (useCases.isNotEmpty()) provider?.unbind(*useCases.toTypedArray())
            executor.shutdown()
        }
    }

    LaunchedEffect(camera, torch) {
        camera?.let { active ->
            if (active.cameraInfo.hasFlashUnit()) active.cameraControl.enableTorch(torch)
        }
    }
    LaunchedEffect(focusPoint) {
        if (focusPoint != null) {
            delay(1100)
            focusPoint = null
        }
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LabSurface(Modifier.fillMaxWidth().weight(1f)) {
            Box(
                Modifier.fillMaxSize().pointerInput(camera) {
                    detectTapGestures { point ->
                        camera?.let { active ->
                            val meterPoint = previewView.meteringPointFactory.createPoint(point.x, point.y)
                            val focus = FocusMeteringAction.Builder(meterPoint)
                                .setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                            active.cameraControl.startFocusAndMetering(focus)
                            focusPoint = point
                            feedback(context, app)
                        }
                    }
                }
            ) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                if (filter != 0) {
                    val frame = bitmap
                    if (frame != null) {
                        Image(
                            frame.asImageBitmap(), "Live ${filters[filter]} camera feed",
                            Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(Modifier.fillMaxSize().background(LabColors.bg), contentAlignment = Alignment.Center) {
                            Text("Processing live pixels…", color = LabColors.cyan)
                        }
                    }
                }
                Box(
                    Modifier.align(Alignment.TopStart).padding(12.dp)
                        .background(Color.Black.copy(alpha = .64f), RoundedCornerShape(12.dp)).padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("LIVE / ${filters[filter].uppercase()}", color = LabColors.cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text("${"%.0f".format(captureFps)} camera FPS · $frameSize", color = Color.White, fontSize = 11.sp)
                        if (filter != 0) Text("${"%.1f".format(processingMs)} ms / effect frame", color = Color.White.copy(alpha = .72f), fontSize = 10.sp)
                    }
                }
                Text(
                    "Tap to focus", color = Color.White.copy(alpha = .85f), fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp)
                        .background(Color.Black.copy(alpha = .45f), RoundedCornerShape(8.dp)).padding(horizontal = 12.dp, vertical = 6.dp)
                )
                focusPoint?.let { point ->
                    Canvas(Modifier.fillMaxSize()) {
                        drawCircle(LabColors.cyan, 30.dp.toPx(), point, style = Stroke(2.dp.toPx()))
                        drawCircle(LabColors.cyan.copy(alpha = .25f), 35.dp.toPx(), point)
                    }
                }
                if (connecting && error == null) {
                    Box(Modifier.fillMaxSize().background(LabColors.bg.copy(alpha = .8f)), contentAlignment = Alignment.Center) {
                        Text("Opening camera…", color = LabColors.text)
                    }
                }
                error?.let { message ->
                    Box(Modifier.fillMaxSize().background(LabColors.bg.copy(alpha = .94f)).padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Camera unavailable", color = LabColors.pink, fontWeight = FontWeight.Bold)
                            Text(message, color = LabColors.text, fontSize = 13.sp)
                            Text("Close another camera app, then reopen Camera FX.", color = LabColors.muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        ControlPanel {
            ChoiceChips(filters, filter) { selected ->
                filter = selected
                bitmap = null
                feedback(context, app)
            }
            if (filter != 0) LabSlider("Effect intensity", intensity, { intensity = it }, .1f..1f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { lens = if (lens == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK },
                    enabled = canFlip, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = LabColors.purple)
                ) { Text("Flip camera") }
                Button(
                    onClick = { torch = !torch }, enabled = camera?.cameraInfo?.hasFlashUnit() == true,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = if (torch) LabColors.amber else LabColors.panel)
                ) { Text(if (torch) "Torch on" else "Torch off", color = if (torch) LabColors.bg else LabColors.text) }
            }
            Text(
                if (filter == 3) "Thermal palette maps brightness; it does not measure heat."
                else "Frames stay on device · quality follows Settings",
                color = LabColors.muted, fontSize = 10.sp
            )
        }
    }
}

/** Reuses pixel buffers and samples padded or interleaved YUV_420_888 planes correctly. */
private class CameraFrameProcessor {
    private var pixels = IntArray(0)
    private var output = IntArray(0)
    private var luminance = IntArray(0)

    fun process(image: ImageProxy, filter: Int, strength: Float, quality: Float, mirror: Boolean): Bitmap {
        val crop = image.cropRect
        val targetWidth = (crop.width() * (.4f + quality.coerceIn(.35f, 1f) * .6f)).toInt().coerceIn(160, 640)
        val width = min(crop.width(), targetWidth)
        val height = max(1, crop.height() * width / crop.width())
        val planes = image.planes
        val y = planes[0].buffer.duplicate()
        val u = planes[1].buffer.duplicate()
        val v = planes[2].buffer.duplicate()
        if (pixels.size != width * height) {
            pixels = IntArray(width * height)
            output = IntArray(width * height)
            luminance = IntArray(width * height)
        }
        val luma = if (filter == 2) luminance else null
        for (row in 0 until height) {
            val sourceY = crop.top + row * crop.height() / height
            for (col in 0 until width) {
                val sourceX = crop.left + col * crop.width() / width
                val yValue = (y.get(sourceY * planes[0].rowStride + sourceX * planes[0].pixelStride).toInt() and 255)
                val uValue = (u.get((sourceY / 2) * planes[1].rowStride + (sourceX / 2) * planes[1].pixelStride).toInt() and 255) - 128
                val vValue = (v.get((sourceY / 2) * planes[2].rowStride + (sourceX / 2) * planes[2].pixelStride).toInt() and 255) - 128
                val yy = max(0, yValue - 16)
                val r = ((298 * yy + 409 * vValue + 128) shr 8).coerceIn(0, 255)
                val g = ((298 * yy - 100 * uValue - 208 * vValue + 128) shr 8).coerceIn(0, 255)
                val b = ((298 * yy + 516 * uValue + 128) shr 8).coerceIn(0, 255)
                val index = row * width + col
                pixels[index] = rgb(r, g, b)
                luma?.set(index, (r * 77 + g * 150 + b * 29) shr 8)
            }
        }
        val blocks = (3 + strength * 22).toInt()
        val drift = (2 + strength * 14).toInt()
        for (row in 0 until height) {
            for (col in 0 until width) {
                val i = row * width + col
                val original = pixels[i]
                val r = (original shr 16) and 255
                val g = (original shr 8) and 255
                val b = original and 255
                val grey = (r * 77 + g * 150 + b * 29) shr 8
                val effect = when (filter) {
                    1 -> rgb(grey, grey, grey)
                    2 -> {
                        // Central-difference edge detector, colored by edge orientation.
                        val luminance = luma!!
                        val left = luminance[row * width + (col - 1).coerceAtLeast(0)]
                        val right = luminance[row * width + (col + 1).coerceAtMost(width - 1)]
                        val up = luminance[(row - 1).coerceAtLeast(0) * width + col]
                        val down = luminance[(row + 1).coerceAtMost(height - 1) * width + col]
                        val dx = abs(right - left)
                        val dy = abs(down - up)
                        val edge = ((dx + dy) * (2f + strength * 4f)).toInt().coerceIn(0, 255)
                        rgb((edge * .75f + dx * .7f).toInt().coerceAtMost(255), edge, (edge + dy).coerceAtMost(255))
                    }
                    3 -> {
                        // A color map of image brightness, not a temperature measurement.
                        val t = grey / 255f
                        val red = (255 * (1.5f - abs(4 * t - 3))).toInt().coerceIn(0, 255)
                        val green = (255 * (1.5f - abs(4 * t - 2))).toInt().coerceIn(0, 255)
                        val blue = (255 * (1.5f - abs(4 * t - 1))).toInt().coerceIn(0, 255)
                        rgb(red, green, blue)
                    }
                    4 -> {
                        val sampled = pixels[(row / blocks * blocks).coerceAtMost(height - 1) * width + (col / blocks * blocks).coerceAtMost(width - 1)]
                        rgb((((sampled shr 16) and 255) / 32) * 32, (((sampled shr 8) and 255) / 32) * 32, ((sampled and 255) / 32) * 32)
                    }
                    5 -> rgb(255 - r, 255 - g, 255 - b)
                    6 -> {
                        val levels = (8 - strength * 5).toInt().coerceAtLeast(2)
                        val interval = 255f / (levels - 1)
                        rgb((r / interval).toInt().let { (it * interval).toInt() }, (g / interval).toInt().let { (it * interval).toInt() }, (b / interval).toInt().let { (it * interval).toInt() })
                    }
                    7 -> {
                        val left = pixels[row * width + (col - drift).coerceAtLeast(0)]
                        val right = pixels[row * width + (col + drift).coerceAtMost(width - 1)]
                        rgb((left shr 16) and 255, g, right and 255)
                    }
                    else -> original
                }
                // Pixel-art and channel-drift strengths control geometry; the rest blend pixels.
                output[i] = if (filter == 4 || filter == 7 || filter == 2) effect else blend(original, effect, strength)
            }
        }
        val raw = Bitmap.createBitmap(output, width, height, Bitmap.Config.ARGB_8888)
        val rotation = image.imageInfo.rotationDegrees
        if (rotation == 0 && !mirror) return raw
        val transform = Matrix().apply {
            postRotate(rotation.toFloat())
            if (mirror) postScale(-1f, 1f)
        }
        val oriented = Bitmap.createBitmap(raw, 0, 0, width, height, transform, true)
        if (oriented !== raw) raw.recycle()
        return oriented
    }
}

private fun rgb(r: Int, g: Int, b: Int): Int = (255 shl 24) or (r shl 16) or (g shl 8) or b

private fun blend(original: Int, effect: Int, amount: Float): Int {
    val inverse = 1f - amount
    return rgb(
        (((original shr 16) and 255) * inverse + ((effect shr 16) and 255) * amount).toInt(),
        (((original shr 8) and 255) * inverse + ((effect shr 8) and 255) * amount).toInt(),
        ((original and 255) * inverse + (effect and 255) * amount).toInt()
    )
}
