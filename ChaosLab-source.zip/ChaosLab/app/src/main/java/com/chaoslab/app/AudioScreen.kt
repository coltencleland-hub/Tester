package com.chaoslab.app

import android.Manifest
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private data class AudioFrame(
    val waveform: FloatArray,
    val spectrum: FloatArray,
    val rms: Float,
    val peak: Float,
    val dbfs: Float,
    val dominantHz: Float,
    val sampleRate: Int
)

/** PCM capture and FFT run off the UI thread. Captured samples never leave this process. */
private class MicrophoneEngine {
    val frames = MutableStateFlow<AudioFrame?>(null)
    val error = MutableStateFlow<String?>(null)
    val recording = MutableStateFlow(false)
    private val generation = AtomicInteger(0)
    private var job: Job? = null
    private var retiringJob: Job? = null
    @Volatile private var recorder: AudioRecord? = null

    fun start(scope: CoroutineScope) {
        if (job?.isActive == true) return
        val token = generation.incrementAndGet()
        val previous = retiringJob
        error.value = null
        job = scope.launch(Dispatchers.IO) {
            var audio: AudioRecord? = null
            try {
                previous?.join()
                ensureActive()
                var sampleRate = 44100
                var minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minBuffer <= 0) {
                    sampleRate = 22050
                    minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                }
                check(minBuffer > 0) { "This device does not support microphone PCM capture." }
                audio = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
                    .setBufferSizeInBytes(max(minBuffer, 4096)).build()
                check(audio.state == AudioRecord.STATE_INITIALIZED) { "Microphone could not initialize. Another app may be using it." }
                ensureActive()
                if (token != generation.get()) return@launch
                recorder = audio
                audio.startRecording()
                check(audio.recordingState == AudioRecord.RECORDSTATE_RECORDING) { "Microphone could not start. Check Android's microphone privacy switch." }
                recording.value = true
                val samples = ShortArray(1024)
                val smoothed = FloatArray(64)
                while (token == generation.get()) {
                    ensureActive()
                    var read = 0
                    while (read < samples.size && token == generation.get()) {
                        val count = audio.read(samples, read, samples.size - read, AudioRecord.READ_BLOCKING)
                        if (count < 0) throw IllegalStateException("Microphone read failed ($count). Reopen the screen to retry.")
                        if (count == 0) { ensureActive(); continue }
                        read += count
                    }
                    if (read == samples.size && token == generation.get()) frames.value = analyze(samples, sampleRate, smoothed)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (failure: Exception) {
                if (token == generation.get()) error.value = if (failure is SecurityException)
                    "Microphone permission was revoked. Reopen this experiment to grant access."
                else failure.message ?: "Microphone capture failed on this device."
            } finally {
                runCatching { audio?.stop() }
                runCatching { audio?.release() }
                if (recorder === audio) recorder = null
                if (token == generation.get()) recording.value = false
            }
        }
    }

    fun stop() {
        generation.incrementAndGet()
        job?.let { it.cancel(); retiringJob = it }
        job = null
        // Stop unblocks READ_BLOCKING promptly; release belongs to the worker's finally block.
        runCatching { recorder?.stop() }
        recording.value = false
    }
}

private fun analyze(samples: ShortArray, sampleRate: Int, smoothed: FloatArray): AudioFrame {
    val n = samples.size
    val real = FloatArray(n)
    val imaginary = FloatArray(n)
    val waveform = FloatArray(n / 2)
    var sumSquares = 0.0
    var peak = 0f
    for (i in samples.indices) {
        val value = samples[i] / 32768f
        real[i] = value * (.5f - .5f * cos(2f * PI.toFloat() * i / (n - 1)))
        sumSquares += value * value
        peak = max(peak, abs(value))
        if (i % 2 == 0) waveform[i / 2] = value
    }
    // Iterative radix-2 FFT, with a Hann window to reduce leakage between bins.
    var reverse = 0
    for (i in 1 until n) {
        var bit = n shr 1
        while (reverse and bit != 0) { reverse = reverse xor bit; bit = bit shr 1 }
        reverse = reverse xor bit
        if (i < reverse) { val temp = real[i]; real[i] = real[reverse]; real[reverse] = temp }
    }
    var length = 2
    while (length <= n) {
        val angle = -2f * PI.toFloat() / length
        val stepReal = cos(angle)
        val stepImaginary = sin(angle)
        var start = 0
        while (start < n) {
            var wr = 1f
            var wi = 0f
            for (i in 0 until length / 2) {
                val a = start + i
                val b = a + length / 2
                val br = real[b] * wr - imaginary[b] * wi
                val bi = real[b] * wi + imaginary[b] * wr
                real[b] = real[a] - br
                imaginary[b] = imaginary[a] - bi
                real[a] += br
                imaginary[a] += bi
                val nextWr = wr * stepReal - wi * stepImaginary
                wi = wr * stepImaginary + wi * stepReal
                wr = nextWr
            }
            start += length
        }
        length = length shl 1
    }
    val magnitudes = FloatArray(n / 2)
    var dominantBin = 1
    var strongest = 0f
    for (i in 1 until n / 2) {
        val magnitude = sqrt(real[i] * real[i] + imaginary[i] * imaginary[i]) * 4f / n
        magnitudes[i] = magnitude
        if (magnitude > strongest) { strongest = magnitude; dominantBin = i }
    }
    val lowHz = sampleRate.toFloat() / n
    val highHz = sampleRate / 2f
    val bands = FloatArray(smoothed.size)
    for (band in bands.indices) {
        val low = exp(ln(lowHz) + (ln(highHz) - ln(lowHz)) * band / bands.size)
        val high = exp(ln(lowHz) + (ln(highHz) - ln(lowHz)) * (band + 1) / bands.size)
        val from = (low * n / sampleRate).toInt().coerceIn(1, magnitudes.lastIndex)
        val lastBinExclusive = max(from + 1, (high * n / sampleRate).toInt()).coerceAtMost(magnitudes.size)
        var maximum = 0f
        for (i in from until lastBinExclusive) maximum = max(maximum, magnitudes[i])
        // Decibel scaling reveals quieter harmonics while preserving real silence as zero.
        val normalized = ((20f * log10(max(maximum, 0.000001f)) + 80f) / 80f).coerceIn(0f, 1f)
        smoothed[band] += (normalized - smoothed[band]) * if (normalized > smoothed[band]) .65f else .18f
        bands[band] = smoothed[band]
    }
    val rms = sqrt(sumSquares / n).toFloat()
    return AudioFrame(waveform, bands, rms, peak, (20f * log10(max(rms, .00000001f))).coerceAtLeast(-160f),
        if (strongest > .0001f) dominantBin.toFloat() * sampleRate / n else 0f, sampleRate)
}

@Composable
fun AudioScreen(app: AppState) {
    PermissionGate(Manifest.permission.RECORD_AUDIO, "Open the sound spectrum", "Allow microphone access for live waveform and frequency analysis. Audio is processed on your phone and is never saved.") {
        MicrophoneScreen(app)
    }
}

@Composable
private fun MicrophoneScreen(app: AppState) {
    val engine = remember { MicrophoneEngine() }
    val scope = rememberCoroutineScope()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val audio by engine.frames.collectAsState()
    val error by engine.error.collectAsState()
    val recording by engine.recording.collectAsState()
    var paused by remember { mutableStateOf(false) }
    var mode by remember { mutableIntStateOf(0) }
    var gain by remember { mutableFloatStateOf(2f) }
    var phase by remember { mutableFloatStateOf(0f) }
    var frame by remember { mutableIntStateOf(0) }
    DisposableEffect(lifecycle, paused) {
        fun start() { if (!paused) engine.start(scope) }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> start()
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP, Lifecycle.Event.ON_DESTROY -> engine.stop()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) start()
        onDispose { lifecycle.removeObserver(observer); engine.stop() }
    }
    SimulationLoop(paused = paused) { dt ->
        phase += dt * if (app.reducedMotion) .1f else .35f
        frame++
        app.activeObjects = if (recording) 64 else 0
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (recording) "● MICROPHONE LIVE" else if (paused) "○ LISTENING PAUSED" else "○ MICROPHONE IDLE",
                color = if (recording) LabColors.cyan else LabColors.muted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text(audio?.let { "${it.sampleRate / 1000f} kHz · FFT 1024" } ?: "Awaiting PCM samples",
                color = LabColors.muted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        LabSurface(Modifier.fillMaxWidth().height(maxOf(190.dp, maxHeight - 285.dp))) {
            Canvas(Modifier.fillMaxSize().padding(16.dp)) {
                @Suppress("UNUSED_VARIABLE") val drawFrame = frame
                val data = audio ?: return@Canvas
                val w = size.width
                val h = size.height
                val center = Offset(w / 2, h / 2)
                val shortest = min(w, h)
                val intensity = (data.rms * gain * 5f).coerceIn(0f, 1f)
                drawCircle(Brush.radialGradient(listOf(LabColors.purple.copy(alpha = .14f + intensity * .12f), Color.Transparent), center, shortest * .65f), shortest * .65f, center)
                when (mode) {
                    0 -> {
                        val baseline = h * .86f
                        for (line in 1..5) drawLine(LabColors.muted.copy(alpha = .1f), Offset(0f, baseline * line / 5), Offset(w, baseline * line / 5), 1f)
                        val spacing = w / data.spectrum.size
                        for (i in data.spectrum.indices) {
                            val level = (data.spectrum[i] * sqrt(gain)).coerceIn(0f, 1f)
                            val barHeight = level * h * .72f
                            val x = i * spacing
                            val color = spectrumColor(i.toFloat() / data.spectrum.size)
                            drawRoundRect(Brush.verticalGradient(listOf(color, color.copy(alpha = .15f)), baseline - barHeight, baseline),
                                Offset(x, baseline - barHeight), androidx.compose.ui.geometry.Size(max(1f, spacing * .65f), max(1f, barHeight)),
                                androidx.compose.ui.geometry.CornerRadius(spacing * .3f))
                        }
                    }
                    1 -> {
                        val radius = shortest * .24f
                        drawCircle(LabColors.cyan.copy(alpha = .12f), radius, center, style = Stroke(1.dp.toPx()))
                        for (i in data.spectrum.indices) {
                            val angle = (2f * PI.toFloat() * i / data.spectrum.size) - PI.toFloat() / 2
                            val direction = Offset(cos(angle), sin(angle))
                            val magnitude = (data.spectrum[i] * sqrt(gain)).coerceIn(0f, 1f) * shortest * .22f
                            val color = spectrumColor(i.toFloat() / data.spectrum.size)
                            drawLine(color.copy(alpha = .15f), center + direction * radius, center + direction * (radius + magnitude), 8.dp.toPx())
                            drawLine(color, center + direction * radius, center + direction * (radius + magnitude), 2.dp.toPx())
                        }
                        drawCircle(LabColors.purple.copy(alpha = .12f), radius * (.8f + intensity * .2f), center)
                    }
                    2 -> {
                        for (i in 0..6) drawLine(LabColors.muted.copy(alpha = .12f), Offset(0f, h * i / 6), Offset(w, h * i / 6), 1f)
                        drawLine(LabColors.cyan.copy(alpha = .25f), Offset(0f, h / 2), Offset(w, h / 2), 1f)
                        val path = Path()
                        for (i in data.waveform.indices) {
                            val x = i.toFloat() / data.waveform.lastIndex * w
                            val y = h / 2 - (data.waveform[i] * gain).coerceIn(-1f, 1f) * h * .42f
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        drawPath(path, LabColors.cyan.copy(alpha = .13f), style = Stroke(10.dp.toPx()))
                        drawPath(path, LabColors.cyan, style = Stroke(1.8.dp.toPx()))
                    }
                    else -> {
                        for (ring in 0 until 8) {
                            val path = Path()
                            val radius = shortest * (.07f + ring * .046f)
                            for (i in 0..128) {
                                val index = (i + ring * 5) % data.spectrum.size
                                val angle = i * 2f * PI.toFloat() / 128f + phase * (if (ring % 2 == 0) 1f else -1f)
                                val distortion = data.spectrum[index] * gain.coerceAtMost(4f) * shortest * .018f
                                val point = center + Offset(cos(angle), sin(angle)) * (radius + distortion)
                                if (i == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y)
                            }
                            path.close()
                            drawPath(path, spectrumColor(ring / 8f).copy(alpha = .75f), style = Stroke((1f + intensity * 1.7f).dp.toPx()))
                        }
                    }
                }
            }
            if (audio == null || error != null) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                    Text(error ?: "Listening for real sound…", color = if (error == null) LabColors.text else LabColors.pink, fontSize = 16.sp)
                    Text("Music, a voice, a clap — every shape starts with microphone samples.", color = LabColors.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            AudioMetric("LEVEL", audio?.let { "${audioNumber(it.dbfs)} dBFS" } ?: "—", LabColors.cyan)
            AudioMetric("RMS", audio?.let { "${audioNumber(it.rms * 100f)}%" } ?: "—", LabColors.purple)
            AudioMetric("DOMINANT", audio?.let { if (it.dominantHz > 0f) "${it.dominantHz.toInt()} Hz" else "Quiet" } ?: "—", LabColors.pink)
        }
        ControlPanel {
            ChoiceChips(listOf("Spectrum", "Radial", "Waveform", "Orbit"), mode) { mode = it }
            LabSlider("Visual gain ×${audioNumber(gain)}", gain, { gain = it }, .5f..8f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (audio?.peak?.let { it > .98f } == true) "Input clipping · lower sound level" else audio?.let { "Log spectrum · ${it.sampleRate / 1024} Hz – ${it.sampleRate / 2000} kHz*" } ?: "Logarithmic frequency bands", color = if (audio?.peak?.let { it > .98f } == true) LabColors.amber else LabColors.muted,
                    fontSize = 10.sp, modifier = Modifier.padding(top = 12.dp))
                OutlinedButton(onClick = {
                    if (error != null && !paused) { engine.stop(); engine.start(scope) } else paused = !paused
                }) { Text(if (error != null && !paused) "Retry" else if (paused) "Listen" else "Pause") }
            }
            Text("*Frequency range follows your device's sample rate. dBFS measures digital input, not calibrated sound pressure.", color = LabColors.muted, fontSize = 10.sp)
        }
    }
    }
}

@Composable
private fun AudioMetric(label: String, value: String, color: Color) {
    Column {
        Text(label, color = LabColors.muted, fontSize = 9.sp)
        Text(value, color = color, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
    }
}

private fun audioNumber(value: Float) = String.format(Locale.US, "%.1f", value)
private fun spectrumColor(position: Float): Color {
    return if (position < .5f) androidx.compose.ui.graphics.lerp(LabColors.cyan, LabColors.purple, position * 2f)
    else androidx.compose.ui.graphics.lerp(LabColors.purple, LabColors.pink, (position - .5f) * 2f)
}
