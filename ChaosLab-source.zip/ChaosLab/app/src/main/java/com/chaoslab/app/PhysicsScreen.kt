package com.chaoslab.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/** An actual rigid-circle simulation: spatial hashing, impulses and drawn static colliders. */
@Composable
fun PhysicsScreen(app: AppState) {
    val context = LocalContext.current
    val density = LocalDensity.current.density
    val tilt = rememberPhysicsTilt()
    val engine = remember { PhysicsEngine(density) }
    var frame by remember { mutableIntStateOf(0) }
    var bodyCount by remember { mutableIntStateOf(0) }
    var paused by remember { mutableStateOf(false) }
    var gravity by remember { mutableFloatStateOf(1f) }
    var tiltEnabled by remember { mutableStateOf(true) }
    var tool by remember { mutableIntStateOf(0) }
    val currentTool by rememberUpdatedState(tool)
    val baseCount = (300 * app.quality * app.stressMultiplier).toInt().coerceIn(100, 1200)
    val maxCount = (700 * app.quality * app.stressMultiplier).toInt().coerceIn(200, 2400)

    LaunchedEffect(baseCount, maxCount) {
        engine.initialCount = baseCount
        engine.maxCount = maxCount
        if (engine.width > 0f && engine.balls.size < baseCount) engine.spawn(baseCount - engine.balls.size)
        bodyCount = engine.balls.size
    }
    SimulationLoop(paused = paused) { dt ->
        val motionFactor = if (app.reducedMotion) 0.6f else 1f
        engine.step(
            dt * motionFactor,
            if (tiltEnabled) -tilt.x * 95f * density else 0f,
            330f * density * gravity + if (tiltEnabled) tilt.y * 65f * density else 0f
        )
        app.activeObjects = engine.balls.size
        bodyCount = engine.balls.size
        frame++
    }

    val scene: @Composable (Modifier) -> Unit = { modifier ->
        LabSurface(modifier) {
            Canvas(
                Modifier.fillMaxSize()
                    .onSizeChanged {
                        engine.resize(it.width.toFloat(), it.height.toFloat())
                        bodyCount = engine.balls.size
                    }
                    .pointerInput(engine) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val chosenTool = currentTool
                            var lastSpawn = down.position
                            var lastWall = down.position
                            when (chosenTool) {
                                0 -> engine.spawnAt(down.position.x, down.position.y, 3)
                                1 -> engine.beginWall(down.position)
                                2 -> engine.beginGrab(down.position)
                            }
                            down.consume()
                            bodyCount = engine.balls.size
                            frame++
                            var isDown = true
                            while (isDown) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                val position = change.position
                                if (change.pressed) {
                                    when (chosenTool) {
                                        0 -> if ((position - lastSpawn).getDistance() > 14f * density) {
                                            engine.spawnAt(position.x, position.y, 2)
                                            lastSpawn = position
                                        }
                                        1 -> if ((position - lastWall).getDistance() > 4f * density) {
                                            engine.extendWall(position)
                                            lastWall = position
                                        }
                                        2 -> engine.moveGrab(position, change.uptimeMillis)
                                    }
                                }
                                change.consume()
                                bodyCount = engine.balls.size
                                frame++
                                isDown = change.pressed
                            }
                            if (chosenTool == 1) engine.finishWall()
                            if (chosenTool == 2) engine.releaseGrab()
                            bodyCount = engine.balls.size
                            app.activeObjects = engine.balls.size
                            frame++
                        }
                    }
            ) {
                @Suppress("UNUSED_VARIABLE") val redraw = frame
                drawRect(Brush.verticalGradient(listOf(Color(0xFF0A1020), Color(0xFF111327))))
                val grid = 26f * density
                var gx = 0f
                while (gx < size.width) {
                    drawLine(Color.White.copy(alpha = 0.045f), Offset(gx, 0f), Offset(gx, size.height), 1f)
                    gx += grid
                }
                var gy = 0f
                while (gy < size.height) {
                    drawLine(Color.White.copy(alpha = 0.045f), Offset(0f, gy), Offset(size.width, gy), 1f)
                    gy += grid
                }
                for (wall in engine.walls) {
                    if (wall.size < 2) continue
                    val path = Path().apply {
                        moveTo(wall[0].x, wall[0].y)
                        for (i in 1 until wall.size) lineTo(wall[i].x, wall[i].y)
                    }
                    drawPath(path, LabColors.cyan.copy(alpha = 0.12f), style = Stroke(12f * density, cap = StrokeCap.Round))
                    drawPath(path, LabColors.cyan.copy(alpha = 0.92f), style = Stroke(3f * density, cap = StrokeCap.Round))
                }
                for (ball in engine.balls) {
                    val center = Offset(ball.x, ball.y)
                    val color = physicsPalette[ball.color]
                    if (app.quality > 0.55f) drawCircle(color.copy(alpha = 0.085f), ball.radius * 1.7f, center)
                    drawCircle(color, ball.radius, center)
                    drawCircle(Color.White.copy(alpha = 0.32f), ball.radius * 0.25f,
                        center + Offset(-ball.radius * 0.27f, -ball.radius * 0.27f))
                }
                for (wave in engine.waves) {
                    val opacity = (1f - wave.age / 0.65f).coerceIn(0f, 1f)
                    drawCircle(LabColors.pink.copy(alpha = opacity * 0.65f), wave.age * 530f * density,
                        Offset(wave.x, wave.y), style = Stroke(2f * density))
                }
                engine.grabbed?.let {
                    drawCircle(Color.White.copy(alpha = 0.8f), it.radius + 5f * density,
                        Offset(it.x, it.y), style = Stroke(1.5f * density))
                }
            }
            Row(
                Modifier.align(Alignment.TopStart).padding(12.dp)
                    .background(Color(0xC9111728), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                Text("$bodyCount bodies", color = LabColors.cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(if (paused) "PAUSED" else "LIVE", color = if (paused) LabColors.amber else LabColors.muted, fontSize = 10.sp)
            }
            if (bodyCount == 0) {
                Text("Tap to release a little chaos", Modifier.align(Alignment.Center), color = LabColors.muted)
            }
        }
    }
    val controls: @Composable () -> Unit = {
        ControlPanel {
            ChoiceChips(listOf("Spawn", "Draw walls", "Grab & throw"), tool) { tool = it }
            Text(
                when (tool) {
                    1 -> "Draw solid obstacles. Balls bounce off every stroke."
                    2 -> "Catch a ball, drag it, then let go to throw it."
                    else -> "Tap or sweep to spawn. Tilt your phone to steer gravity."
                },
                color = LabColors.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp)
            )
            LabSlider("Gravity · ${"%.1f".format(gravity)}×", gravity, { gravity = it }, 0f..2f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PhysicsAction("+40", Modifier.weight(1f)) {
                    engine.spawn(40); bodyCount = engine.balls.size; app.activeObjects = bodyCount
                    feedback(context, app); frame++
                }
                PhysicsAction("Explode", Modifier.weight(1.4f), LabColors.pink) {
                    engine.explode(engine.width / 2f, engine.height / 2f)
                    feedback(context, app, strong = true)
                    frame++
                }
                PhysicsAction(if (paused) "Play" else "Pause", Modifier.weight(1.2f)) { paused = !paused }
                PhysicsAction("Reset", Modifier.weight(1.1f)) {
                    engine.reset(baseCount); bodyCount = engine.balls.size; app.activeObjects = bodyCount; frame++
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(if (tilt.available) "Phone tilt" else "Accelerometer unavailable", color = LabColors.muted, fontSize = 12.sp,
                    modifier = Modifier.weight(1f))
                Switch(checked = tiltEnabled && tilt.available, onCheckedChange = { tiltEnabled = it }, enabled = tilt.available,
                    colors = SwitchDefaults.colors(checkedThumbColor = LabColors.cyan, checkedTrackColor = LabColors.cyan.copy(alpha = 0.25f)))
                TextButton(onClick = { engine.clearWalls(); frame++ }) {
                    Text("Clear walls", color = LabColors.cyan, fontSize = 11.sp)
                }
            }
        }
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
        if (maxWidth >= 560.dp && maxWidth > maxHeight) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                scene(Modifier.fillMaxHeight().weight(1f))
                Column(Modifier.width(290.dp).fillMaxHeight().verticalScroll(rememberScrollState())) { controls() }
            }
        } else {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                scene(Modifier.fillMaxWidth().weight(1f))
                controls()
            }
        }
    }
}

@Composable
private fun PhysicsAction(label: String, modifier: Modifier, color: Color = LabColors.cyan, action: () -> Unit) {
    FilledTonalButton(
        onClick = action, modifier = modifier.height(38.dp), shape = RoundedCornerShape(11.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp),
        colors = ButtonDefaults.filledTonalButtonColors(containerColor = color.copy(alpha = 0.13f), contentColor = color)
    ) { Text(label, fontSize = 12.sp, maxLines = 1) }
}

private val physicsPalette = arrayOf(Color(0xFF5AE2E8), Color(0xFFAD89FF), Color(0xFFFF70AB),
    Color(0xFFFFBE67), Color(0xFF7FEEBA), Color(0xFF69A4FF))

private class PhysicsTilt(val available: Boolean) {
    var x by mutableFloatStateOf(0f)
    var y by mutableFloatStateOf(0f)
}

@Suppress("DEPRECATION")
@Composable
private fun rememberPhysicsTilt(): PhysicsTilt {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val manager = remember(context) { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val accelerometer = remember(manager) { manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) }
    val tilt = remember(accelerometer) { PhysicsTilt(accelerometer != null) }
    DisposableEffect(manager, accelerometer, lifecycle) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val rotation = (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
                val sx = event.values[0]
                val sy = event.values[1]
                val (x, y) = when (rotation) {
                    Surface.ROTATION_90 -> -sy to sx
                    Surface.ROTATION_180 -> -sx to -sy
                    Surface.ROTATION_270 -> sy to -sx
                    else -> sx to sy
                }
                tilt.x = tilt.x * 0.8f + x.coerceIn(-12f, 12f) * 0.2f
                tilt.y = tilt.y * 0.8f + y.coerceIn(-12f, 12f) * 0.2f
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        var registered = false
        fun register() {
            if (!registered && accelerometer != null) registered = manager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        }
        fun unregister() { manager.unregisterListener(listener); registered = false }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> register()
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> unregister()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) register()
        onDispose { lifecycle.removeObserver(observer); unregister() }
    }
    return tilt
}

private class PhysicsBall(var x: Float, var y: Float, var vx: Float, var vy: Float, val radius: Float, val color: Int) {
    val inverseMass = 1f / (radius * radius)
}
private class PhysicsWave(val x: Float, val y: Float, var age: Float = 0f)
private class PhysicsSegment(val a: Offset, val b: Offset)

private class PhysicsEngine(private val density: Float) {
    var width = 0f
    var height = 0f
    var initialCount = 225
    var maxCount = 700
    val balls = ArrayList<PhysicsBall>(700)
    val walls = ArrayList<MutableList<Offset>>()
    val waves = ArrayList<PhysicsWave>()
    var grabbed: PhysicsBall? = null
        private set
    private var currentWall: MutableList<Offset>? = null
    private val random = Random.Default
    private val cellSize = 22f * density
    private var columns = 1
    private var rows = 1
    private var heads = IntArray(1) { -1 }
    private var next = IntArray(2400)
    private var obstacleBuckets = arrayOfNulls<MutableList<Int>>(1)
    private val segments = ArrayList<PhysicsSegment>()
    private var lastGrabTime = 0L
    private var throwVx = 0f
    private var throwVy = 0f

    fun resize(w: Float, h: Float) {
        if (w < 1f || h < 1f) return
        val previousWidth = width
        val previousHeight = height
        width = w
        height = h
        columns = max(1, ceil(w / cellSize).toInt())
        rows = max(1, ceil(h / cellSize).toInt())
        heads = IntArray(columns * rows) { -1 }
        obstacleBuckets = arrayOfNulls(columns * rows)
        if (previousWidth > 0f && previousHeight > 0f) {
            for (ball in balls) { ball.x *= w / previousWidth; ball.y *= h / previousHeight }
            for (wall in walls) for (i in wall.indices) wall[i] = Offset(wall[i].x * w / previousWidth, wall[i].y * h / previousHeight)
        } else spawn(initialCount)
        rebuildObstacles()
    }

    fun spawn(count: Int) {
        if (width <= 0f || height <= 0f) return
        repeat(min(count, maxCount - balls.size).coerceAtLeast(0)) {
            addBall(random.nextFloat() * (width - 24f * density) + 12f * density,
                random.nextFloat() * max(1f, height * 0.75f - 24f * density) + 12f * density)
        }
    }

    fun spawnAt(x: Float, y: Float, count: Int) {
        if (width <= 0f || height <= 0f) return
        repeat(min(count, maxCount - balls.size).coerceAtLeast(0)) {
            addBall(x + (random.nextFloat() - 0.5f) * 24f * density,
                y + (random.nextFloat() - 0.5f) * 24f * density)
        }
    }

    private fun addBall(x: Float, y: Float) {
        val radius = (4.8f + random.nextFloat() * 4.8f) * density
        balls.add(PhysicsBall(x.coerceIn(radius, max(radius, width - radius)),
            y.coerceIn(radius, max(radius, height - radius)),
            (random.nextFloat() - 0.5f) * 95f * density,
            (random.nextFloat() - 0.5f) * 95f * density, radius, random.nextInt(physicsPalette.size)))
    }

    fun reset(count: Int) { releaseGrab(); balls.clear(); waves.clear(); clearWalls(); spawn(count) }

    fun explode(x: Float, y: Float) {
        for (ball in balls) {
            if (ball === grabbed) continue
            var dx = ball.x - x
            var dy = ball.y - y
            if (abs(dx) + abs(dy) < 0.1f) { dx = 1f; dy = 1f }
            val distance = sqrt(dx * dx + dy * dy)
            val impulse = 620f * density / (1f + distance / (140f * density))
            ball.vx += dx / distance * impulse
            ball.vy += dy / distance * impulse
        }
        waves.add(PhysicsWave(x, y))
        if (waves.size > 8) waves.removeAt(0)
    }

    fun beginWall(point: Offset) {
        if (walls.size >= 24) walls.removeAt(0)
        val wall = arrayListOf(point)
        walls.add(wall)
        currentWall = wall
        rebuildObstacles()
    }

    fun extendWall(point: Offset) {
        val wall = currentWall ?: return
        if (wall.size >= 200) return
        wall.add(Offset(point.x.coerceIn(0f, width), point.y.coerceIn(0f, height)))
        rebuildObstacles()
    }

    fun finishWall() { currentWall = null }
    fun clearWalls() { currentWall = null; walls.clear(); segments.clear(); obstacleBuckets = arrayOfNulls(columns * rows) }

    fun beginGrab(point: Offset) {
        var nearest: PhysicsBall? = null
        var best = 50f * density
        for (ball in balls) {
            val distance = sqrt((ball.x - point.x) * (ball.x - point.x) + (ball.y - point.y) * (ball.y - point.y))
            if (distance < best) { nearest = ball; best = distance }
        }
        grabbed = nearest
        lastGrabTime = 0
        throwVx = 0f
        throwVy = 0f
    }

    fun moveGrab(point: Offset, time: Long) {
        val ball = grabbed ?: return
        val x = point.x.coerceIn(ball.radius, max(ball.radius, width - ball.radius))
        val y = point.y.coerceIn(ball.radius, max(ball.radius, height - ball.radius))
        if (lastGrabTime != 0L) {
            val dt = ((time - lastGrabTime) / 1000f).coerceIn(0.005f, 0.1f)
            throwVx = (throwVx * 0.4f + (x - ball.x) / dt * 0.6f).coerceIn(-1500f * density, 1500f * density)
            throwVy = (throwVy * 0.4f + (y - ball.y) / dt * 0.6f).coerceIn(-1500f * density, 1500f * density)
        }
        ball.x = x; ball.y = y; ball.vx = 0f; ball.vy = 0f
        lastGrabTime = time
    }

    fun releaseGrab() { grabbed?.let { it.vx = throwVx; it.vy = throwVy }; grabbed = null }

    private fun rebuildObstacles() {
        segments.clear()
        obstacleBuckets = arrayOfNulls(columns * rows)
        val margin = 12f * density
        for (wall in walls) for (i in 1 until wall.size) {
            val segment = PhysicsSegment(wall[i - 1], wall[i])
            val index = segments.size
            segments.add(segment)
            val x0 = floor((min(segment.a.x, segment.b.x) - margin) / cellSize).toInt().coerceIn(0, columns - 1)
            val x1 = floor((max(segment.a.x, segment.b.x) + margin) / cellSize).toInt().coerceIn(0, columns - 1)
            val y0 = floor((min(segment.a.y, segment.b.y) - margin) / cellSize).toInt().coerceIn(0, rows - 1)
            val y1 = floor((max(segment.a.y, segment.b.y) + margin) / cellSize).toInt().coerceIn(0, rows - 1)
            for (y in y0..y1) for (x in x0..x1) {
                val bucket = y * columns + x
                val list = obstacleBuckets[bucket] ?: ArrayList<Int>().also { obstacleBuckets[bucket] = it }
                list.add(index)
            }
        }
    }

    fun step(delta: Float, gravityX: Float, gravityY: Float) {
        if (width <= 0f || height <= 0f) return
        val elapsed = delta.coerceIn(0f, 1f / 30f)
        if (elapsed <= 0f) return
        // Limit movement per substep so fast throws cannot tunnel through thin drawn walls.
        val speedLimit = 1000f * density
        var fastest = 0f
        for (ball in balls) {
            val speed = sqrt(ball.vx * ball.vx + ball.vy * ball.vy)
            if (speed > speedLimit) { ball.vx *= speedLimit / speed; ball.vy *= speedLimit / speed }
            fastest = max(fastest, min(speed, speedLimit))
        }
        val substeps = ceil((fastest + max(abs(gravityX), abs(gravityY)) * elapsed) * elapsed / (4f * density)).toInt().coerceIn(3, 10)
        val dt = elapsed / substeps
        if (next.size < balls.size) next = IntArray(balls.size + 256)
        repeat(substeps) {
            val drag = exp((-0.045f * dt).toDouble()).toFloat()
            for (ball in balls) {
                if (ball === grabbed) continue
                ball.vx = ((ball.vx + gravityX * dt) * drag).coerceIn(-1800f * density, 1800f * density)
                ball.vy = ((ball.vy + gravityY * dt) * drag).coerceIn(-1800f * density, 1800f * density)
                ball.x += ball.vx * dt
                ball.y += ball.vy * dt
                boundaries(ball)
                collideWalls(ball)
            }
            repeat(2) {
                heads.fill(-1)
                for (i in balls.indices) {
                    val ball = balls[i]
                    val cell = cellIndex(ball.x, ball.y)
                    next[i] = heads[cell]
                    heads[cell] = i
                }
                for (i in balls.indices) {
                    val a = balls[i]
                    val x = floor(a.x / cellSize).toInt().coerceIn(0, columns - 1)
                    val y = floor(a.y / cellSize).toInt().coerceIn(0, rows - 1)
                    for (cy in max(0, y - 1)..min(rows - 1, y + 1)) for (cx in max(0, x - 1)..min(columns - 1, x + 1)) {
                        var j = heads[cy * columns + cx]
                        while (j >= 0) {
                            if (j > i) collideBalls(a, balls[j])
                            j = next[j]
                        }
                    }
                }
            }
            for (ball in balls) if (ball !== grabbed) { boundaries(ball); collideWalls(ball) }
        }
        val iterator = waves.iterator()
        while (iterator.hasNext()) { val wave = iterator.next(); wave.age += elapsed; if (wave.age > 0.65f) iterator.remove() }
    }

    private fun cellIndex(x: Float, y: Float) = floor(y / cellSize).toInt().coerceIn(0, rows - 1) * columns +
        floor(x / cellSize).toInt().coerceIn(0, columns - 1)

    private fun boundaries(ball: PhysicsBall) {
        if (ball.x < ball.radius) { ball.x = ball.radius; if (ball.vx < 0f) ball.vx *= -0.87f }
        if (ball.x > width - ball.radius) { ball.x = max(ball.radius, width - ball.radius); if (ball.vx > 0f) ball.vx *= -0.87f }
        if (ball.y < ball.radius) { ball.y = ball.radius; if (ball.vy < 0f) ball.vy *= -0.87f }
        if (ball.y > height - ball.radius) {
            ball.y = max(ball.radius, height - ball.radius)
            if (ball.vy > 0f) ball.vy *= -0.80f
            ball.vx *= 0.995f
        }
    }

    private fun collideBalls(a: PhysicsBall, b: PhysicsBall) {
        var dx = b.x - a.x
        var dy = b.y - a.y
        val radii = a.radius + b.radius
        val squared = dx * dx + dy * dy
        if (squared >= radii * radii) return
        val distance = if (squared < 0.0001f) { dx = 0.01f; dy = 0f; 0.01f } else sqrt(squared)
        val nx = dx / distance
        val ny = dy / distance
        val inverseA = if (a === grabbed) 0f else a.inverseMass
        val inverseB = if (b === grabbed) 0f else b.inverseMass
        val total = inverseA + inverseB
        if (total <= 0f) return
        val correction = max(0f, radii - distance - 0.03f * density) * 0.90f / total
        a.x -= nx * correction * inverseA
        a.y -= ny * correction * inverseA
        b.x += nx * correction * inverseB
        b.y += ny * correction * inverseB
        val normalVelocity = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny
        if (normalVelocity >= 0f) return
        val restitution = if (abs(normalVelocity) < 25f * density) 0.05f else 0.91f
        val impulse = -(1f + restitution) * normalVelocity / total
        a.vx -= impulse * inverseA * nx
        a.vy -= impulse * inverseA * ny
        b.vx += impulse * inverseB * nx
        b.vy += impulse * inverseB * ny
    }

    private fun collideWalls(ball: PhysicsBall) {
        val candidates = obstacleBuckets[cellIndex(ball.x, ball.y)] ?: return
        for (index in candidates) {
            val wall = segments[index]
            val sx = wall.b.x - wall.a.x
            val sy = wall.b.y - wall.a.y
            val lengthSquared = sx * sx + sy * sy
            if (lengthSquared < 0.0001f) continue
            val t = (((ball.x - wall.a.x) * sx + (ball.y - wall.a.y) * sy) / lengthSquared).coerceIn(0f, 1f)
            val cx = wall.a.x + sx * t
            val cy = wall.a.y + sy * t
            var dx = ball.x - cx
            var dy = ball.y - cy
            val squared = dx * dx + dy * dy
            val limit = ball.radius + 1.5f * density
            if (squared >= limit * limit) continue
            val distance: Float
            if (squared < 0.0001f) {
                val length = sqrt(lengthSquared)
                dx = -sy / length
                dy = sx / length
                distance = 1f
            } else distance = sqrt(squared)
            val nx = dx / distance
            val ny = dy / distance
            ball.x += nx * (limit - distance)
            ball.y += ny * (limit - distance)
            val velocity = ball.vx * nx + ball.vy * ny
            if (velocity < 0f) {
                val restitution = if (abs(velocity) < 18f * density) 0.05f else 0.88f
                ball.vx -= (1f + restitution) * velocity * nx
                ball.vy -= (1f + restitution) * velocity * ny
            }
        }
    }
}
