package com.chaoslab.app

import android.os.Build
import android.os.Debug
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun SettingsScreen(app: AppState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SettingsCard("THE EXPERIENCE") {
            ToggleRow("Haptic feedback", "Feel interactions and Chaos Button events.", app.haptics) { app.haptics = it }
            ToggleRow("Chaos sound", "Procedural tones for randomized events.", app.sound) { app.sound = it }
            ToggleRow("Gentler motion", "Slower visuals and shorter navigation transitions.", app.reducedMotion) { app.reducedMotion = it }
            ToggleRow("Keep screen awake", "Stay awake while the lab is in the foreground.", app.keepAwake) { app.keepAwake = it }
        }
        SettingsCard("PERFORMANCE") {
            ToggleRow("FPS overlay", "Live frame timing, heap memory and object count.", app.showFps) { app.showFps = it }
            Spacer(Modifier.height(8.dp))
            LabSlider("Simulation quality", app.quality, { app.quality = it }, .35f..1f)
            Text("Quality controls particle counts, drawing detail and camera processing resolution. Lower it to keep older devices smooth.", color = LabColors.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        SettingsCard("MADE FOR CURIOSITY") {
            Text("Chaos Lab  /  1.0.0", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Native Kotlin + Jetpack Compose. Every visual is drawn from code. Microphone samples and camera frames are processed locally and never stored.", color = LabColors.muted, lineHeight = 21.sp, fontSize = 13.sp)
            Text("Hardware availability varies by device. Motion Lab reports sensors that are actually present.", color = LabColors.muted, lineHeight = 18.sp, fontSize = 12.sp)
            Text("A little secret: tap the Chaos Lab title seven times.", color = LabColors.cyan, fontSize = 12.sp)
        }
        TextButton(onClick = { app.showFps = false; app.haptics = true; app.sound = true; app.quality = .75f; app.reducedMotion = false; app.keepAwake = true }) { Text("Restore default settings") }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SettingsCard(label: String, content: @Composable ColumnScope.() -> Unit) {
    LabSurface(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text(label, color = LabColors.cyan, fontSize = 9.sp, letterSpacing = 1.6.sp)
            content()
        }
    }
}

@Composable
private fun ToggleRow(title: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(description, color = LabColors.muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = LabColors.cyan, checkedThumbColor = LabColors.bg))
    }
}

@Composable
fun DeveloperScreen(app: AppState) {
    val sensors = rememberLabSensors()
    var refresh by remember { mutableIntStateOf(0) }
    var timer by remember { mutableFloatStateOf(0f) }
    SimulationLoop { timer += it; if (timer >= .5f) { refresh++; timer = 0f } }
    val nativeHeap = remember(refresh) { Debug.getNativeHeapAllocatedSize() / 1048576f }
    val memory = remember(refresh) { Debug.MemoryInfo().also { Debug.getMemoryInfo(it) } }
    fun fmt(n: Float) = "%.2f".format(Locale.US, n)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsCard("INTERNAL STATE") {
            DataLine("Build", "debug · API ${Build.VERSION.SDK_INT}")
            DataLine("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
            DataLine("Scene / objects", "${app.scene} / ${app.activeObjects}")
            DataLine("FPS / mean frame", "${fmt(app.fps)} / ${fmt(app.frameMs)} ms")
            DataLine("95th percentile", "${fmt(app.p95Ms)} ms")
            DataLine("Frames over 25 ms", "${app.jank}")
            DataLine("Java / native heap", "${fmt(app.heapMb)} / ${fmt(nativeHeap)} MB")
            DataLine("PSS / heap limit", "${memory.totalPss / 1024} / ${Runtime.getRuntime().maxMemory() / 1048576} MB")
            DataLine("CPU stress checksum", "%.6f".format(app.cpuChecksum))
            ToggleRow("Show performance overlay", "Overlay remains visible in every experiment.", app.showFps) { app.showFps = it }
            TextButton(onClick = { app.jank = 0 }) { Text("Reset frame counter") }
        }
        SettingsCard("SENSOR BUS") {
            DataLine("Accelerometer", if (sensors.hasAccelerometer) "${fmt(sensors.acceleration.x)}, ${fmt(sensors.acceleration.y)}, ${fmt(sensors.acceleration.z)} m/s²" else "Unavailable")
            DataLine("Gyroscope", if (sensors.hasGyroscope) "${fmt(sensors.gyroscope.x)}, ${fmt(sensors.gyroscope.y)}, ${fmt(sensors.gyroscope.z)} rad/s" else "Unavailable")
            DataLine("Magnetometer", if (sensors.hasMagnetometer) "${fmt(sensors.magnetic.x)}, ${fmt(sensors.magnetic.y)}, ${fmt(sensors.magnetic.z)} µT" else "Unavailable")
            DataLine("Yaw / pitch / roll", if (sensors.hasOrientation) "${fmt(sensors.orientation.azimuth)}° / ${fmt(sensors.orientation.pitch)}° / ${fmt(sensors.orientation.roll)}°" else "Unavailable")
            DataLine("Listener", if (sensors.active) "Registered · foreground" else "Stopped")
            DataLine("Timestamp", "${sensors.lastTimestampNanos} ns")
        }
        SettingsCard("STRESS TESTS") {
            Text("Increase the load, then open an experiment and watch the overlay. These settings reset when the process ends.", color = LabColors.muted, fontSize = 12.sp, lineHeight = 18.sp)
            Text("Object / drawing multiplier", fontSize = 13.sp)
            ChoiceChips(listOf("1×", "2×", "3×", "4×"), app.stressMultiplier - 1) { app.stressMultiplier = it + 1; app.showFps = true }
            LabSlider("CPU math operations per frame (×1,000)", app.cpuStress.toFloat(), { app.cpuStress = it.toInt(); app.showFps = true }, 0f..50f)
            Text("Retained memory", fontSize = 13.sp)
            ChoiceChips(listOf("Off", "+8 MB", "+16 MB", "+32 MB"), listOf(0, 8, 16, 32).indexOf(app.memoryStressMb).coerceAtLeast(0)) { app.setMemoryStress(listOf(0, 8, 16, 32)[it]); app.showFps = true }
            Button(onClick = { app.stressMultiplier = 1; app.cpuStress = 0; app.setMemoryStress(0) }) { Text("Stop all stress tests") }
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun DataLine(label: String, value: String) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = LabColors.muted, fontSize = 11.sp)
        Text(value, color = LabColors.text, fontSize = 13.sp)
    }
}
