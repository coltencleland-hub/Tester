package com.chaoslab.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/** Four materials share force fields but keep their own physical behavior. */
@Composable
fun ParticleScreen(app: AppState) {
    val engine = remember { ParticleEngine() }
    var selected by remember { mutableIntStateOf(0) }
    var interaction by remember { mutableIntStateOf(0) }
    var density by remember { mutableFloatStateOf(0.55f) }
    var paused by remember { mutableStateOf(false) }
    var repellingWells by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }
    var particleCount by remember { mutableIntStateOf(0) }
    val elements = listOf("Fire", "Water", "Smoke", "Sparks")
    val descriptions = listOf(
        "Heat rises. Flames cool into smoke.",
        "Droplets flow, settle and gather together.",
        "Buoyant clouds ride a turbulent current.",
        "Hot sparks arc, bounce and leave trails."
    )
    val accent = listOf(LabColors.amber, LabColors.cyan, LabColors.purple, LabColors.pink)[selected]

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(app, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                engine.pointer = null
                frame++
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            engine.pointer = null
            if (app.scene == "particles") app.activeObjects = 0
        }
    }
    SimulationLoop(paused = paused) { seconds ->
        engine.material = selected
        engine.mode = interaction
        engine.capacity = (1800 * app.quality * app.stressMultiplier).toInt().coerceIn(200, 6500)
        engine.emissionRate = (70f + density * 340f) * app.quality * app.stressMultiplier
        engine.step(seconds.coerceAtMost(0.033f) * if (app.reducedMotion) 0.45f else 1f)
        app.activeObjects = engine.particles.size
        particleCount = engine.particles.size
        frame++
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxHeight < 440.dp
        val landscape = maxWidth > 520.dp && maxWidth > maxHeight * 1.4f
        val controlsHeight = if (landscape) (maxHeight - 18.dp).coerceAtLeast(48.dp)
            else if (compact) (maxHeight * 0.35f).coerceAtLeast(60.dp) else 245.dp
        val canvas: @Composable (Modifier) -> Unit = { canvasModifier ->
            LabSurface(canvasModifier) {
                Canvas(
                    Modifier.fillMaxSize()
                        .onSizeChanged { engine.resize(it.width.toFloat(), it.height.toFloat()) }
                        .pointerInput(selected, interaction, repellingWells) {
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                engine.material = selected
                                engine.mode = interaction
                                engine.pointer = down.position
                                frame++
                                try {
                                    if (interaction == 3) {
                                        engine.toggleWell(down.position, if (repellingWells) -1f else 1f)
                                    } else if (interaction == 0) {
                                        engine.emit(down.position, 18)
                                        particleCount = engine.particles.size
                                        app.activeObjects = particleCount
                                    }
                                    down.consume()
                                    var previous = down.position
                                    do {
                                        val event = awaitPointerEvent()
                                        val change = event.changes.firstOrNull { it.id == down.id }
                                        if (change != null) {
                                            engine.pointer = change.position
                                            frame++
                                            if (interaction == 0 && change.pressed) {
                                                engine.emitAlong(previous, change.position)
                                                particleCount = engine.particles.size
                                                app.activeObjects = particleCount
                                            }
                                            previous = change.position
                                            change.consume()
                                        }
                                    } while (event.changes.any { it.id == down.id && it.pressed })
                                } finally {
                                    // Pointer coroutines are cancelled when a gesture or input mode is replaced.
                                    // Always release the field, including while the simulation is paused.
                                    engine.pointer = null
                                    frame++
                                }
                            }
                        }
                ) {
                    // The frame is observable; the engine itself uses mutable arrays to avoid per-frame allocations.
                    @Suppress("UNUSED_VARIABLE") val renderedFrame = frame
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF080E20), Color(0xFF11172A))))
                    val grid = 42.dp.toPx()
                    for (x in 0..(size.width / grid).toInt()) {
                        drawLine(Color.White.copy(alpha = 0.025f), Offset(x * grid, 0f), Offset(x * grid, size.height))
                    }
                    for (y in 0..(size.height / grid).toInt()) {
                        drawLine(Color.White.copy(alpha = 0.025f), Offset(0f, y * grid), Offset(size.width, y * grid))
                    }
                    drawRect(Color(0xFF23304A), Offset(0f, size.height - 7f), Size(size.width, 7f))
                    engine.wells.forEach { well ->
                        val color = if (well.polarity > 0) LabColors.purple else LabColors.pink
                        val phase = (engine.time * 0.3f) % 1f
                        for (i in 0..2) {
                            val ring = ((phase + i / 3f) % 1f)
                            drawCircle(color.copy(alpha = (1f - ring) * 0.22f), 16f + ring * 52f, well.position, style = Stroke(1.5f))
                        }
                        drawCircle(color.copy(alpha = 0.14f), 18f, well.position)
                        drawCircle(color, 4f, well.position)
                        drawLine(color, well.position - Offset(7f, 0f), well.position + Offset(7f, 0f), strokeWidth = 2f)
                        if (well.polarity > 0) drawLine(color, well.position - Offset(0f, 7f), well.position + Offset(0f, 7f), strokeWidth = 2f)
                    }
                    engine.particles.forEach { p ->
                        val at = Offset(p.x, p.y)
                        val life = (1f - p.age / p.lifetime).coerceIn(0f, 1f)
                        when (p.type) {
                            0 -> {
                                val heat = (p.heat / 1f).coerceIn(0f, 1f)
                                val color = Color(1f, 0.16f + 0.72f * heat, 0.03f + 0.38f * heat, min(0.92f, life * 1.4f))
                                drawCircle(Color(0xFFFF5C27).copy(alpha = life * 0.08f), p.radius * 2.4f, at)
                                drawCircle(color, p.radius * (0.45f + heat * 0.55f), at)
                            }
                            1 -> {
                                drawCircle(Color(0xFF156FA9).copy(alpha = 0.32f * life), p.radius * 1.45f, at)
                                drawCircle(Color(0xFF42CFFF).copy(alpha = 0.77f * life), p.radius, at)
                                drawCircle(Color(0xFFBDF5FF).copy(alpha = 0.5f * life), p.radius * 0.29f, at - Offset(p.radius * 0.24f, p.radius * 0.22f))
                            }
                            2 -> {
                                val fadeIn = min(1f, p.age * 2f + 0.15f)
                                drawCircle(Color(0xFFA9A9D5).copy(alpha = 0.11f * life * fadeIn), p.radius * (1f + p.age * 0.6f), at)
                                drawCircle(Color(0xFFC5C7EA).copy(alpha = 0.055f * life * fadeIn), p.radius * (1.6f + p.age * 0.8f), at)
                            }
                            else -> {
                                val color = if (p.heat > 0.4f) Color(0xFFFFE09A) else Color(0xFFFF718F)
                                val trail = Offset(p.x - p.vx * 0.055f, p.y - p.vy * 0.055f)
                                drawLine(color.copy(alpha = life * 0.25f), trail, at, strokeWidth = p.radius * 2f, cap = StrokeCap.Round)
                                drawLine(color.copy(alpha = life), Offset(p.px, p.py), at, strokeWidth = p.radius, cap = StrokeCap.Round)
                                drawCircle(color.copy(alpha = life), p.radius, at)
                            }
                        }
                    }
                    engine.pointer?.let { touch ->
                        if (interaction == 1 || interaction == 2) {
                            drawCircle(accent.copy(alpha = 0.045f), 110f, touch)
                            drawCircle(accent.copy(alpha = 0.55f), 24f, touch, style = Stroke(1.5f))
                            if (interaction == 2) {
                                for (i in 0..3) {
                                    val angle = engine.time * 2f + i * PI.toFloat() / 2f
                                    val point = touch + Offset(cos(angle) * 24f, sin(angle) * 24f)
                                    drawCircle(accent, 3f, point)
                                }
                            } else {
                                drawLine(accent, touch - Offset(8f, 0f), touch + Offset(8f, 0f), strokeWidth = 1.5f)
                                drawLine(accent, touch - Offset(0f, 8f), touch + Offset(0f, 8f), strokeWidth = 1.5f)
                            }
                        }
                    }
                }
                Row(Modifier.align(Alignment.TopStart).padding(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(elements[selected].uppercase(), color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xC0080E20)).padding(horizontal = 9.dp, vertical = 6.dp))
                    Text("$particleCount particles", color = LabColors.text, fontSize = 11.sp,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xC0080E20)).padding(horizontal = 9.dp, vertical = 6.dp))
                }
                Text(
                    when (interaction) {
                        0 -> if (paused) "PAUSED · paint particles, then press Play" else "Touch & drag to paint ${elements[selected].lowercase()}"
                        1 -> "Hold & drag to pull particles toward your finger"
                        2 -> "Hold & drag to create a spinning vortex"
                        else -> "Tap to place a ${if (repellingWells) "repelling" else "gravity"} well · tap a well to remove"
                    },
                    color = LabColors.muted, fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xD0080E20)).padding(8.dp)
                )
            }
        }
        val controls: @Composable () -> Unit = {
            ControlPanel {
                Column(Modifier.heightIn(max = controlsHeight).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    ChoiceChips(elements, selected) { selected = it }
                    Text(descriptions[selected], color = LabColors.muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 2.dp))
                    ChoiceChips(listOf("Paint", "Attract", "Swirl", "Wells"), interaction) { interaction = it }
                    if (interaction == 3) {
                        ChoiceChips(listOf("Gravity +", "Repel −"), if (repellingWells) 1 else 0) { repellingWells = it == 1 }
                    }
                    LabSlider("Emission density", density, { density = it }, 0.1f..1f)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { paused = !paused }, colors = ButtonDefaults.buttonColors(containerColor = accent.copy(alpha = 0.18f), contentColor = accent), modifier = Modifier.weight(1f)) {
                            Text(if (paused) "Play" else "Pause", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = { engine.burst(selected); frame++; particleCount = engine.particles.size; app.activeObjects = engine.particles.size }, modifier = Modifier.weight(1f)) { Text("Burst", fontSize = 12.sp) }
                        OutlinedButton(onClick = { engine.clear(); frame++; particleCount = 0; app.activeObjects = 0 }, modifier = Modifier.weight(1f)) { Text("Clear", fontSize = 12.sp) }
                    }
                }
            }
        }
        if (landscape) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                canvas(Modifier.weight(1f).fillMaxHeight())
                Column(Modifier.width(230.dp).fillMaxHeight()) { controls() }
            }
        } else {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                canvas(Modifier.weight(1f).fillMaxWidth())
                controls()
            }
        }
    }
}

private class LabParticle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var type: Int, var radius: Float, var lifetime: Float, var heat: Float = 1f,
    var age: Float = 0f, var phase: Float = 0f,
    var px: Float = x, var py: Float = y
)

private data class ParticleWell(val position: Offset, val polarity: Float)

/** A frame-based CPU simulation with a spatial hash for local water pressure/viscosity. */
private class ParticleEngine {
    val particles = ArrayList<LabParticle>(2000)
    val wells = ArrayList<ParticleWell>()
    private val random = Random(System.nanoTime())
    private val buckets = HashMap<Int, MutableList<LabParticle>>()
    private val recycledBuckets = ArrayList<MutableList<LabParticle>>()
    private var width = 0f
    private var height = 0f
    private var accumulator = 0f
    private var autoSeeded = false
    var pointer: Offset? = null
    var material = 0
    var mode = 0
    var capacity = 1800
    var emissionRate = 260f
    var time = 0f
        private set

    fun resize(w: Float, h: Float) {
        if (width > 0 && height > 0) {
            val sx = w / width
            val sy = h / height
            particles.forEach { it.x *= sx; it.y *= sy }
            for (i in wells.indices) wells[i] = wells[i].copy(position = Offset(wells[i].position.x * sx, wells[i].position.y * sy))
        }
        width = w
        height = h
        if (!autoSeeded && w > 0 && h > 0) {
            autoSeeded = true
            emit(Offset(width * 0.5f, height * 0.68f), 95)
        }
    }

    fun clear() {
        particles.clear()
        wells.clear()
        accumulator = 0f
    }

    fun toggleWell(position: Offset, polarity: Float) {
        val existing = wells.indexOfFirst { (it.position - position).getDistance() < 36f }
        if (existing >= 0) wells.removeAt(existing)
        else if (wells.size < 12) wells.add(ParticleWell(position, polarity))
    }

    fun burst(type: Int) {
        material = type
        val at = pointer ?: Offset(width * 0.5f, height * 0.6f)
        emit(at, min(capacity / 4, 340), radial = true)
    }

    fun emitAlong(a: Offset, b: Offset) {
        val distance = (b - a).getDistance()
        val segments = (distance / 9f).toInt().coerceIn(1, 24)
        for (i in 1..segments) {
            val f = i.toFloat() / segments
            emit(a + (b - a) * f, if (material == 2) 2 else 3)
        }
    }

    fun emit(at: Offset, count: Int, radial: Boolean = false) {
        if (width <= 0 || height <= 0) return
        for (i in 0 until min(count, capacity - particles.size).coerceAtLeast(0)) {
            val angle = random.nextFloat() * PI.toFloat() * 2f
            val spread = if (material == 2) 14f else 9f
            val jitter = random.nextFloat() * spread
            val x = (at.x + cos(angle) * jitter).coerceIn(3f, max(3f, width - 3f))
            val y = (at.y + sin(angle) * jitter).coerceIn(3f, max(3f, height - 3f))
            var vx: Float
            var vy: Float
            var radius: Float
            var lifetime: Float
            when (material) {
                0 -> { vx = random.nextFloat() * 76f - 38f; vy = -45f - random.nextFloat() * 100f; radius = 3.5f + random.nextFloat() * 5.5f; lifetime = 0.65f + random.nextFloat() * 1.15f }
                1 -> { vx = random.nextFloat() * 100f - 50f; vy = random.nextFloat() * 80f - 20f; radius = 3.5f + random.nextFloat() * 1.5f; lifetime = 26f + random.nextFloat() * 18f }
                2 -> { vx = random.nextFloat() * 40f - 20f; vy = -10f - random.nextFloat() * 36f; radius = 5f + random.nextFloat() * 7f; lifetime = 3f + random.nextFloat() * 4f }
                else -> { vx = cos(angle) * (60f + random.nextFloat() * 280f); vy = sin(angle) * 220f - 155f; radius = 1.1f + random.nextFloat() * 1.2f; lifetime = 0.65f + random.nextFloat() * 1.5f }
            }
            if (radial) {
                val force = if (material == 2) 75f else 220f + random.nextFloat() * 240f
                vx += cos(angle) * force
                vy += sin(angle) * force
            }
            particles.add(LabParticle(x, y, vx, vy, material, radius, lifetime, phase = random.nextFloat() * 12f))
        }
    }

    fun step(dt: Float) {
        if (width <= 0 || height <= 0 || dt <= 0f) return
        time += dt
        pointer?.let {
            if (mode == 0) {
                accumulator += emissionRate * dt
                val n = accumulator.toInt()
                accumulator -= n
                emit(it, n)
            }
        }
        if (particles.size > capacity) particles.subList(0, particles.size - capacity).clear()
        // Two shorter steps keep neighbor pressure stable even at 30 FPS.
        val step = dt / 2f
        repeat(2) {
            applyWaterInteractions(step)
            var index = particles.size - 1
            while (index >= 0) {
                val p = particles[index]
                p.age += step
                p.px = p.x
                p.py = p.y
                if (p.age >= p.lifetime && p.type == 0 && particles.size < capacity) {
                    // Cooling flames become smoke, conserving their movement and location.
                    p.type = 2
                    p.age = 0f
                    p.lifetime = 2.1f + random.nextFloat() * 2f
                    p.radius = 4.5f + random.nextFloat() * 3f
                    p.vx *= 0.4f
                    p.vy *= 0.4f
                }
                if (p.age >= p.lifetime || p.x < -100f || p.x > width + 100f || p.y < -150f || p.y > height + 100f) {
                    // Swap removal avoids an O(n) shift for every expiring particle.
                    val last = particles.removeAt(particles.lastIndex)
                    if (index < particles.size) particles[index] = last
                    index--
                    continue
                }
                var ax = 0f
                var ay = 0f
                val drag: Float
                when (p.type) {
                    0 -> {
                        p.heat = (1f - p.age / p.lifetime).coerceIn(0f, 1f)
                        ax = sin(p.y * 0.027f + time * 4f + p.phase) * 80f
                        ay = -100f - 140f * p.heat
                        drag = 0.65f
                    }
                    1 -> { ay = 570f; drag = 0.24f }
                    2 -> {
                        ax = sin(p.y * 0.017f + time * 1.7f + p.phase) * 38f + cos(p.x * 0.013f - time) * 24f
                        ay = -24f + cos(p.x * 0.02f + time * 1.5f + p.phase) * 17f
                        drag = 0.85f
                    }
                    else -> { ay = 380f; drag = 0.6f; p.heat = 1f - p.age / p.lifetime }
                }
                for (well in wells) {
                    val dx = well.position.x - p.x
                    val dy = well.position.y - p.y
                    val d2 = dx * dx + dy * dy + 600f
                    val d = sqrt(d2)
                    val force = (1_850_000f / d2).coerceAtMost(1350f) * well.polarity
                    ax += dx / d * force
                    ay += dy / d * force
                    if (well.polarity > 0) {
                        // A small tangential force prevents everything collapsing to a single dot.
                        ax -= dy / d * force * 0.12f
                        ay += dx / d * force * 0.12f
                    }
                }
                pointer?.let { touch ->
                    if (mode == 1 || mode == 2) {
                        val dx = touch.x - p.x
                        val dy = touch.y - p.y
                        val d = sqrt(dx * dx + dy * dy + 100f)
                        val falloff = (1f - d / max(250f, width * 0.72f)).coerceIn(0f, 1f)
                        if (mode == 1) {
                            val force = 1000f * falloff
                            ax += dx / d * force
                            ay += dy / d * force
                        } else {
                            val force = 1700f * falloff
                            ax += (-dy / d + dx / d * 0.20f) * force
                            ay += (dx / d + dy / d * 0.20f) * force
                        }
                    }
                }
                p.vx = (p.vx + ax * step) * exp(-drag * step)
                p.vy = (p.vy + ay * step) * exp(-drag * step)
                val speed = sqrt(p.vx * p.vx + p.vy * p.vy)
                if (speed > 950f) { p.vx *= 950f / speed; p.vy *= 950f / speed }
                p.x += p.vx * step
                p.y += p.vy * step
                if (p.type == 1 || p.type == 3) {
                    if (p.x < p.radius) { p.x = p.radius; p.vx = abs(p.vx) * 0.5f }
                    if (p.x > width - p.radius) { p.x = width - p.radius; p.vx = -abs(p.vx) * 0.5f }
                    if (p.y > height - p.radius - 7f) {
                        p.y = height - p.radius - 7f
                        p.vy = -abs(p.vy) * if (p.type == 1) 0.18f else 0.55f
                        p.vx *= if (p.type == 1) 0.99f else 0.92f
                    }
                    if (p.y < p.radius) { p.y = p.radius; p.vy = abs(p.vy) * 0.4f }
                }
                index--
            }
        }
    }

    private fun key(x: Int, y: Int) = (x shl 16) xor (y and 0xffff)

    private fun applyWaterInteractions(dt: Float) {
        recycledBuckets.addAll(buckets.values)
        buckets.clear()
        recycledBuckets.forEach { it.clear() }
        val cell = 17f
        for (p in particles) if (p.type == 1) {
            val k = key((p.x / cell).toInt(), (p.y / cell).toInt())
            val bucket = buckets[k] ?: run {
                val list = if (recycledBuckets.isEmpty()) ArrayList<LabParticle>() else recycledBuckets.removeAt(recycledBuckets.lastIndex)
                buckets[k] = list
                list
            }
            bucket.add(p)
        }
        // Cap each neighborhood's work: large stress tests remain bounded even after water piles up.
        for (p in particles) if (p.type == 1) {
            val cx = (p.x / cell).toInt()
            val cy = (p.y / cell).toInt()
            var checked = 0
            neighbors@ for (dy in -1..1) for (dx in -1..1) {
                val bucket = buckets[key(cx + dx, cy + dy)] ?: continue
                for (other in bucket) {
                    if (other === p) continue
                    if (++checked > 36) break@neighbors
                    val ox = p.x - other.x
                    val oy = p.y - other.y
                    val distance2 = ox * ox + oy * oy
                    if (distance2 > cell * cell || distance2 < 0.01f) continue
                    val distance = sqrt(distance2)
                    val nx = ox / distance
                    val ny = oy / distance
                    val rest = p.radius + other.radius + 0.8f
                    if (distance < rest) {
                        val pressure = min(1600f, (rest - distance) * 220f)
                        p.vx += nx * pressure * dt
                        p.vy += ny * pressure * dt
                        // Small position correction avoids soft particles compressing through the floor.
                        val correction = (rest - distance) * 0.065f
                        p.x += nx * correction
                        p.y += ny * correction
                    } else {
                        // Surface cohesion at medium range gathers neighboring droplets.
                        val cohesion = (1f - distance / cell) * 17f
                        p.vx -= nx * cohesion * dt
                        p.vy -= ny * cohesion * dt
                    }
                    val viscosity = (1f - distance / cell) * dt * 1.8f
                    p.vx += (other.vx - p.vx) * viscosity
                    p.vy += (other.vy - p.vy) * viscosity
                }
            }
        }
    }
}
