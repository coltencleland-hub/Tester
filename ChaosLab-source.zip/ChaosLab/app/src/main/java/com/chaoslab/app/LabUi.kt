package com.chaoslab.app

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

object LabColors {
    val bg = Color(0xFF090D14)
    val panel = Color(0xFF121924)
    val cyan = Color(0xFF76F5CC)
    val purple = Color(0xFFAC9CFF)
    val pink = Color(0xFFFF81AA)
    val amber = Color(0xFFFFC676)
    val muted = Color(0xFF8592A6)
    val text = Color(0xFFEAF0F8)
}

@Composable
fun LabSurface(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(LabColors.panel)
        .border(1.dp, Color.White.copy(alpha = .07f), RoundedCornerShape(24.dp)), content = content)
}

@Composable
fun ControlPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
}

@Composable
fun ChoiceChips(options: List<String>, selected: Int, onSelected: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        options.forEachIndexed { i, label ->
            FilterChip(selected = selected == i, onClick = { onSelected(i) }, label = { Text(label, fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = LabColors.cyan.copy(alpha = .16f), selectedLabelColor = LabColors.cyan),
                border = FilterChipDefaults.filterChipBorder(enabled = true, selected = selected == i,
                    borderColor = Color.White.copy(alpha = .1f), selectedBorderColor = LabColors.cyan.copy(alpha = .3f)))
        }
    }
}

@Composable
fun LabSlider(label: String, value: Float, onValueChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float> = 0f..1f) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = LabColors.muted, fontSize = 12.sp)
            Text("%.2f".format(java.util.Locale.US, value), color = LabColors.cyan, fontSize = 12.sp)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValueChange, valueRange = range,
            modifier = Modifier.fillMaxWidth().height(32.dp), colors = SliderDefaults.colors(thumbColor = LabColors.cyan, activeTrackColor = LabColors.cyan))
    }
}

@Composable
fun PermissionGate(permission: String, title: String, explanation: String, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) }
    var denied by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { allowed -> granted = allowed; denied = !allowed }
    LaunchedEffect(permission) { if (!granted) launcher.launch(permission) }
    DisposableEffect(owner, permission) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) granted = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    if (granted) content() else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        LabSurface(Modifier.fillMaxWidth()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(explanation, color = LabColors.muted, lineHeight = 23.sp)
                Text("Processing stays on your device. No recordings are saved or uploaded.", color = LabColors.cyan, fontSize = 12.sp)
                val permanent = denied && context is Activity && !ActivityCompat.shouldShowRequestPermissionRationale(context, permission)
                Button(onClick = {
                    if (permanent) context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
                    else launcher.launch(permission)
                }) { Text(if (permanent) "Open app permissions" else "Enable $title") }
            }
        }
    }
}

@Composable
fun Glyph(name: String, color: Color = LabColors.cyan, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val stroke = Stroke(w * .065f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (name) {
            "back" -> { val p = Path(); p.moveTo(w*.65f,h*.2f);p.lineTo(w*.35f,h*.5f);p.lineTo(w*.65f,h*.8f);drawPath(p,color,style=stroke) }
            "settings" -> {
                drawCircle(color, w*.29f,style=stroke);drawCircle(color,w*.09f,style=stroke)
                repeat(8) { i -> val a = i * Math.PI / 4;val x=kotlin.math.cos(a).toFloat();val y=kotlin.math.sin(a).toFloat();drawLine(color,center+Offset(x,y)*w*.31f,center+Offset(x,y)*w*.42f,w*.08f,StrokeCap.Round) }
            }
            "bolt" -> {val p=Path();p.moveTo(w*.58f,h*.08f);p.lineTo(w*.22f,h*.57f);p.lineTo(w*.49f,h*.57f);p.lineTo(w*.4f,h*.93f);p.lineTo(w*.8f,h*.4f);p.lineTo(w*.55f,h*.4f);p.close();drawPath(p,color)}
            "arrow" -> {drawLine(color,Offset(w*.2f,h*.8f),Offset(w*.8f,h*.2f),w*.065f,StrokeCap.Round);val p=Path();p.moveTo(w*.3f,h*.2f);p.lineTo(w*.8f,h*.2f);p.lineTo(w*.8f,h*.7f);drawPath(p,color,style=stroke)}
            "pause" -> {drawLine(color,Offset(w*.35f,h*.2f),Offset(w*.35f,h*.8f),w*.14f,StrokeCap.Round);drawLine(color,Offset(w*.65f,h*.2f),Offset(w*.65f,h*.8f),w*.14f,StrokeCap.Round)}
            else -> {drawCircle(color,w*.3f,style=stroke);drawCircle(color,w*.07f)}
        }
    }
}
