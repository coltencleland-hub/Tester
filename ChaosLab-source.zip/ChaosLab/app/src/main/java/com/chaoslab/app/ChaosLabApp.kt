package com.chaoslab.app

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlin.math.*

data class Experiment(val route: String, val number: String, val title: String, val subtitle: String, val tag: String, val color: Color)
val experiments = listOf(
    Experiment("physics", "01", "Physics sandbox", "Give gravity a little attitude.", "TILT + TOUCH", LabColors.cyan),
    Experiment("particles", "02", "Particle sandbox", "Paint with fire, water & smoke.", "SIMULATION", LabColors.amber),
    Experiment("audio", "03", "Audio visualizer", "See what your world sounds like.", "MICROPHONE", LabColors.pink),
    Experiment("camera", "04", "Camera FX", "Reality, remixed in real time.", "LIVE CAMERA", LabColors.purple),
    Experiment("motion", "05", "Motion lab", "Find your phone’s sixth sense.", "LIVE SENSORS", Color(0xFF7DBBFF)),
    Experiment("art", "06", "Generative art", "A playground for happy accidents.", "12 ALGORITHMS", Color(0xFFFFA69A)),
    Experiment("chaos", "07", "Chaos button", "One button. Unpredictable energy.", "PRESS AT OWN DELIGHT", LabColors.cyan)
)

@Composable
fun ChaosLabApp() {
    val context = LocalContext.current
    val view = LocalView.current
    val app = remember { AppState(context) }
    var route by rememberSaveable { mutableStateOf("home") }
    var titleTaps by remember { mutableIntStateOf(0) }
    var lastTap by remember { mutableLongStateOf(0) }
    val scheme = darkColorScheme(primary = LabColors.cyan, onPrimary = LabColors.bg, secondary = LabColors.purple,
        background = LabColors.bg, surface = LabColors.panel, onBackground = LabColors.text, onSurface = LabColors.text,
        surfaceVariant = Color(0xFF1C2635), onSurfaceVariant = LabColors.muted, outline = Color(0xFF334255))
    MaterialTheme(colorScheme = scheme, typography = Typography()) {
        PerformanceMonitor(app)
        LaunchedEffect(app) {
            snapshotFlow { listOf(app.showFps, app.haptics, app.sound, app.quality, app.reducedMotion, app.keepAwake) }
                .distinctUntilChanged().collect { app.save() }
        }
        DisposableEffect(view, app.keepAwake) { view.keepScreenOn = app.keepAwake; onDispose { view.keepScreenOn = false } }
        LaunchedEffect(route) { app.scene = route; app.activeObjects = 0 }
        BackHandler(route != "home") { route = "home" }
        Box(Modifier.fillMaxSize().background(LabColors.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().height(66.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (route != "home") IconButton(onClick = { route = "home" }) { Glyph("back", LabColors.text) }
                    else Box(Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(LabColors.cyan.copy(alpha = .12f)), contentAlignment = Alignment.Center) { Glyph("bolt", modifier = Modifier.size(19.dp)) }
                    Spacer(Modifier.width(if (route == "home") 11.dp else 2.dp))
                    Column(Modifier.weight(1f).clickable {
                        val now = SystemClock.elapsedRealtime()
                        titleTaps = if (now - lastTap > 3500) 1 else titleTaps + 1
                        lastTap = now
                        if (titleTaps >= 7) { titleTaps = 0; feedback(context, app, true); route = "developer" }
                    }) {
                        Text("Chaos Lab", fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.5).sp)
                        if (titleTaps in 4..6) Text("${7 - titleTaps} taps to developer mode", color = LabColors.cyan, fontSize = 10.sp)
                        else Text(if (route == "home") "A POCKET EXPERIMENT STUDIO" else "${experiments.firstOrNull { it.route == route }?.tag ?: "LAB CONTROLS"}", fontSize = 8.sp, letterSpacing = 1.5.sp, color = LabColors.muted)
                    }
                    IconButton(onClick = { feedback(context, app); route = if (route == "settings") "home" else "settings" }) { Glyph("settings", LabColors.muted, Modifier.size(21.dp)) }
                }
                if (route != "home") {
                    Text(experiments.firstOrNull { it.route == route }?.title ?: if (route == "developer") "Under the hood" else "Settings",
                        fontSize = 27.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.7).sp)
                    Text(experiments.firstOrNull { it.route == route }?.subtitle ?: if (route == "developer") "Live internals. Real controls. Handle with curiosity." else "Tune your pocket playground.",
                        fontSize = 12.sp, color = LabColors.muted, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
                }
                AnimatedContent(route, modifier = Modifier.weight(1f).fillMaxWidth(), transitionSpec = {
                    (fadeIn(tween(if (app.reducedMotion) 80 else 220)) + slideInHorizontally { if (app.reducedMotion) 0 else it / 20 }) togetherWith fadeOut(tween(130))
                }, label = "Navigation") { screen ->
                    when (screen) {
                        "physics" -> PhysicsScreen(app)
                        "particles" -> ParticleScreen(app)
                        "audio" -> AudioScreen(app)
                        "camera" -> CameraScreen(app)
                        "motion" -> MotionScreen(app)
                        "art" -> ArtScreen(app)
                        "chaos" -> ChaosScreen(app)
                        "settings" -> SettingsScreen(app)
                        "developer" -> DeveloperScreen(app)
                        else -> HomeScreen(app) { feedback(context, app); route = it }
                    }
                }
            }
            if (app.showFps) Column(Modifier.align(Alignment.TopEnd).padding(top = 69.dp, end = 22.dp).clip(RoundedCornerShape(9.dp)).background(Color.Black.copy(alpha = .86f)).border(1.dp, LabColors.cyan.copy(alpha = .25f), RoundedCornerShape(9.dp)).padding(7.dp)) {
                Text("${app.fps.roundToInt()} FPS · ${"%.1f".format(app.frameMs)} ms", color = LabColors.cyan, fontSize = 10.sp)
                Text("${app.heapMb.roundToInt()} MB · ${app.activeObjects} objects", color = LabColors.muted, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun HomeScreen(app: AppState, open: (String) -> Unit) {
    val clock = remember { mutableFloatStateOf(0f) }
    SimulationLoop { clock.floatValue += it * if (app.reducedMotion) .2f else 1f }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val columns = if (maxWidth > 850.dp) 4 else if (maxWidth > 580.dp) 3 else 2
        LazyVerticalGrid(columns = GridCells.Fixed(columns), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 22.dp)) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.padding(top = 12.dp, bottom = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(5.dp).background(LabColors.cyan, RoundedCornerShape(4.dp)))
                        Text("  ALL SYSTEMS CURIOUS", fontSize = 10.sp, letterSpacing = 1.6.sp, color = LabColors.cyan)
                    }
                    Text("Make a little\nbeautiful chaos.", fontSize = if (columns > 2) 44.sp else 36.sp, lineHeight = if (columns > 2) 49.sp else 41.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1.8).sp, modifier = Modifier.padding(top = 12.dp))
                    Text("Seven experiments. No rules. Just play.", color = LabColors.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                LabSurface(Modifier.fillMaxWidth().height(126.dp).clickable { open("chaos") }) {
                    Canvas(Modifier.fillMaxSize()) {
                        val t = clock.floatValue
                        drawRect(Brush.horizontalGradient(listOf(LabColors.cyan.copy(alpha = .08f), LabColors.panel, LabColors.purple.copy(alpha = .08f))))
                        val c = Offset(size.width * .84f, size.height * .54f)
                        for (i in 0..3) rotate(t * (i + 1) * 9, c) {
                            drawOval(if (i % 2 == 0) LabColors.cyan.copy(alpha = .7f) else LabColors.purple.copy(alpha = .6f), c - Offset(48f + i*7, 20f + i*6), Size(96f + i*14, 40f + i*12), style = Stroke(2f))
                        }
                        drawCircle(Brush.radialGradient(listOf(LabColors.cyan.copy(alpha = .4f), Color.Transparent), c, 64f),64f,c)
                        drawCircle(LabColors.cyan, 6f,c)
                    }
                    Column(Modifier.align(Alignment.CenterStart).padding(20.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("FEELING EXPERIMENTAL?", color = LabColors.cyan, fontSize = 9.sp, letterSpacing = 1.3.sp)
                        Text("Let chance take over.", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("Try the Chaos Button", color = LabColors.muted, fontSize = 12.sp); Spacer(Modifier.width(8.dp)); Glyph("arrow", LabColors.cyan, Modifier.size(13.dp)) }
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("THE EXPERIMENTS", fontSize = 10.sp, letterSpacing = 1.8.sp, color = LabColors.muted)
                    Text("07 / READY TO PLAY", fontSize = 9.sp, letterSpacing = .8.sp, color = LabColors.muted)
                }
            }
            items(experiments.take(6), key = { it.route }) { exp ->
                LabSurface(Modifier.fillMaxWidth().height(200.dp).clickable { open(exp.route) }) {
                    MiniArt(exp, clock, Modifier.fillMaxWidth().height(100.dp))
                    Text(exp.number, color = exp.color.copy(alpha = .7f), fontSize = 10.sp, modifier = Modifier.align(Alignment.TopStart).padding(14.dp))
                    Glyph("arrow", LabColors.muted, Modifier.align(Alignment.TopEnd).padding(14.dp).size(14.dp))
                    Column(Modifier.align(Alignment.BottomStart).padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(exp.tag, color = exp.color, fontSize = 7.sp, letterSpacing = 1.2.sp)
                        Text(exp.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.3).sp)
                        Text(exp.subtitle, color = LabColors.muted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("BUILT FROM MATH, MOTION & A LITTLE MISCHIEF", fontSize = 8.sp, letterSpacing = 1.2.sp, color = LabColors.muted.copy(alpha = .65f), modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun MiniArt(exp: Experiment, clock: State<Float>, modifier: Modifier) {
    Canvas(modifier) {
        val t = clock.value
        val c = Offset(size.width*.5f,size.height*.63f)
        drawCircle(Brush.radialGradient(listOf(exp.color.copy(alpha = .12f),Color.Transparent),c,size.width*.48f),size.width*.48f,c)
        when(exp.route) {
            "physics" -> repeat(14) { i -> val r = 7f + i % 4 * 3f;val x = (i * 61f + 31) % size.width;val y = size.height*.58f + sin(t*1.4f+i)*size.height*.23f;drawCircle(exp.color.copy(alpha = .06f),r*1.8f,Offset(x,y));drawCircle(exp.color.copy(alpha = .6f+i%3*.12f),r,Offset(x,y));drawCircle(Color.White.copy(alpha=.45f),r*.22f,Offset(x-r*.3f,y-r*.3f)) }
            "particles" -> repeat(75) { i -> val seed = i * 13.371f;val phase=(t*.3f+i*.057f)%1f;val x=c.x+sin(seed+phase*3)*phase*size.width*.3f;val y=size.height*(.91f-phase*.78f);drawCircle(if(i%3==0) LabColors.pink.copy(alpha=1-phase) else exp.color.copy(alpha=1-phase),1f+(1-phase)*3,Offset(x,y)) }
            "audio" -> repeat(27) { i -> val x=size.width*.13f+i*size.width*.74f/27;val amp=(.2f+abs(sin(i*.43f+t*1.8f))*abs(sin(i*.23f-t)))*size.height*.6f;drawLine(exp.color.copy(alpha=.8f),Offset(x,c.y-amp*.5f),Offset(x,c.y+amp*.5f),size.width*.014f,StrokeCap.Round) }
            "camera" -> {
                repeat(8) { i -> val f=i/8f;drawRoundRect(Color.hsv((f*250+t*20)%360,.7f,.85f).copy(alpha=.5f),Offset(size.width*.18f+i*4,size.height*.25f+i*3),Size(size.width*.64f-i*8,size.height*.66f-i*6),androidx.compose.ui.geometry.CornerRadius(7f),style=Stroke(2f)) }
                drawCircle(exp.color,7f,c)
            }
            "motion" -> rotate(sin(t)*18f,c) {
                val p=Path();p.moveTo(c.x-21,c.y-37);p.lineTo(c.x+24,c.y-27);p.lineTo(c.x+21,c.y+35);p.lineTo(c.x-24,c.y+26);p.close();drawPath(p,exp.color.copy(alpha=.13f));drawPath(p,exp.color,style=Stroke(2f));drawCircle(exp.color,3f,c+Offset(-1,22));drawLine(LabColors.pink,c,c+Offset(36,8),2f);drawLine(LabColors.cyan,c,c+Offset(-10,-43),2f)
            }
            else -> repeat(160) { i -> val a=i*2.39996f+t*.2f;val r=sqrt(i.toFloat())*3.2f;drawCircle(Color.hsv((i*2f+t*10)%360,.5f,1f).copy(alpha=.8f),2f, c+Offset(cos(a)*r,sin(a)*r*.65f)) }
        }
    }
}
