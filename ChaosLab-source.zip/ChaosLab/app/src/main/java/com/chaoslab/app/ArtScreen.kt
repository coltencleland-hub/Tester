package com.chaoslab.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private data class ArtPreset(val title: String, val subtitle: String, val description: String)

private val artPresets = listOf(
    ArtPreset("Flow field", "VECTOR STREAMS", "Streamlines follow a changing trigonometric vector field."),
    ArtPreset("Phyllotaxis", "GOLDEN ANGLE", "The golden angle distributes an evolving sunflower of points."),
    ArtPreset("Galaxy", "SPIRAL DYNAMICS", "Logarithmic spiral arms orbit a glowing galactic core."),
    ArtPreset("Lissajous", "HARMONIC MOTION", "Two oscillators weave a ribbon of changing frequency ratios."),
    ArtPreset("Spirograph", "HYPOTROCHOIDS", "A circle rolling inside another circle traces layered curves."),
    ArtPreset("Fractal tree", "RECURSIVE GROWTH", "Each branch splits recursively while a wind field bends the canopy."),
    ArtPreset("Mandala", "POLAR SYMMETRY", "Nested polar curves produce a rotating radial ornament."),
    ArtPreset("Attractor", "CLIFFORD MAP", "Repeated nonlinear equations reveal a strange attractor."),
    ArtPreset("Interference", "SUPERPOSED WAVES", "Two radial waves add together; drag to move one source."),
    ArtPreset("Cellular", "ELEMENTARY AUTOMATA", "A one-dimensional cellular rule builds the next row from three neighbors."),
    ArtPreset("Terrain", "FRACTAL HEIGHT FIELD", "Layered coherent noise creates a moving perspective wireframe."),
    ArtPreset("Kaleidoscope", "MIRROR TILING", "A moving triangular mosaic repeats in mirrored angular sectors.")
)

@Composable
fun ArtScreen(app: AppState) {
    var preset by rememberSaveable { mutableIntStateOf(0) }
    var complexity by rememberSaveable { mutableFloatStateOf(0.56f) }
    var speed by rememberSaveable { mutableFloatStateOf(0.45f) }
    var randomness by rememberSaveable { mutableFloatStateOf(0.5f) }
    var seed by rememberSaveable { mutableIntStateOf(8132) }
    var paused by rememberSaveable { mutableStateOf(false) }
    var time by remember { mutableFloatStateOf(0f) }
    var touch by remember { mutableStateOf(Offset(0.5f, 0.5f)) }
    var canvasSize by remember { mutableStateOf(IntSize(1, 1)) }
    val context = LocalContext.current
    val detail = ((0.22f + complexity * 0.78f) * app.quality * app.stressMultiplier).coerceIn(0.08f, 3f)
    val cellWidth = (64 + detail * 96).toInt().coerceIn(64, 320)
    val automaton = remember(seed, cellWidth) { ArtAutomaton(cellWidth, seed) }
    var automatonClock by remember(seed, cellWidth) { mutableFloatStateOf(0f) }
    fun reshape(position: Offset) {
        touch = position.artNormalized(canvasSize)
        if (preset == 9) automaton.seedAt(touch.x)
    }
    SimulationLoop(paused) { delta ->
        val scaledDelta = delta * (0.12f + speed * 2.6f) * if (app.reducedMotion) 0.3f else 1f
        time += scaledDelta
        if (preset == 9) {
            automatonClock += scaledDelta
            while (automatonClock > 0.06f) {
                automaton.step(randomness)
                automatonClock -= 0.06f
            }
        }
        app.activeObjects = when (preset) {
            0 -> (180 + 700 * detail).toInt()
            1, 2 -> (250 + 1800 * detail).toInt()
            7 -> (2200 + detail * 7000).toInt()
            9 -> cellWidth * automaton.rows.size
            10 -> ((12 + detail * 16) * (18 + detail * 22)).toInt()
            else -> (150 + detail * 800).toInt()
        }
    }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        LabSurface(Modifier.fillMaxWidth().weight(1f)) {
            Canvas(
                Modifier.fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(canvasSize, automaton, preset) {
                        detectDragGestures(
                            onDragStart = { reshape(it) },
                            onDrag = { change, _ ->
                                change.consume()
                                reshape(change.position)
                            }
                        )
                    }
                    .pointerInput(canvasSize, automaton, preset) {
                        detectTapGestures { reshape(it) }
                    }
            ) {
                val seconds = time
                val center = Offset(size.width / 2f, size.height / 2f)
                drawRect(Color(0xFF080B19))
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFF241142).copy(alpha = 0.7f), Color.Transparent),
                        center, max(size.width, size.height) * 0.65f
                    ), radius = max(size.width, size.height) * 0.65f, center = center
                )
                val frame = ArtFrame(seconds, detail, complexity, randomness, seed, touch)
                when (preset) {
                    0 -> flowField(frame)
                    1 -> phyllotaxis(frame)
                    2 -> spiralGalaxy(frame)
                    3 -> lissajous(frame)
                    4 -> spirograph(frame)
                    5 -> fractalTree(frame)
                    6 -> mandala(frame)
                    7 -> cliffordAttractor(frame)
                    8 -> interference(frame)
                    9 -> cellularArt(automaton, frame)
                    10 -> terrain(frame)
                    else -> kaleidoscope(frame)
                }
            }
            Column(Modifier.align(Alignment.TopStart).padding(16.dp)) {
                Text(artPresets[preset].subtitle, color = LabColors.cyan, style = MaterialTheme.typography.labelSmall)
                Text(artPresets[preset].title, color = Color.White, style = MaterialTheme.typography.titleLarge)
            }
            Text(
                (if (paused) "PAUSED" else "LIVE") + if (preset == 9) " • Drag to seed cells" else " • Drag to reshape",
                modifier = Modifier.align(Alignment.BottomStart).padding(16.dp),
                color = LabColors.muted,
                style = MaterialTheme.typography.labelSmall
            )
            Text(
                "SEED ${seed.toUInt()}",
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                color = LabColors.muted,
                style = MaterialTheme.typography.labelSmall
            )
        }
        Box(Modifier.heightIn(max = 315.dp).verticalScroll(rememberScrollState())) {
            ControlPanel {
                ChoiceChips(artPresets.map { it.title }, preset) { preset = it }
                Text(artPresets[preset].description, color = LabColors.muted, style = MaterialTheme.typography.bodySmall)
                LabSlider("Complexity", complexity, { complexity = it })
                LabSlider("Speed", speed, { speed = it })
                LabSlider("Randomness", randomness, { randomness = it })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { seed = Random.nextInt(); feedback(context, app) }) { Text("New seed") }
                    OutlinedButton(onClick = { paused = !paused }) { Text(if (paused) "Resume" else "Pause") }
                    Spacer(Modifier.weight(1f))
                    Text("12 algorithms", color = LabColors.muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

private fun Offset.artNormalized(size: IntSize) = Offset(
    (x / max(1, size.width)).coerceIn(0f, 1f),
    (y / max(1, size.height)).coerceIn(0f, 1f)
)

private data class ArtFrame(val t: Float, val detail: Float, val complexity: Float, val chaos: Float, val seed: Int, val touch: Offset) {
    val phase: Float get() = ((seed.toLong() and 0xFFFF) / 65535f) * ART_TAU
    fun unit(index: Int, channel: Int = 0): Float = artHash(index + channel * 1973, seed)
    fun color(index: Int, alpha: Float = 1f): Color = Color.hsv(
        ((205f + phase * 30f + index * 0.71f + t * 8f) % 360f + 360f) % 360f,
        0.5f + chaos * 0.3f, 1f, alpha.coerceIn(0f, 1f)
    )
}

private const val ART_TAU = 6.2831855f

private fun artHash(x: Int, seed: Int): Float {
    var v = x * 374761393 + seed * 668265263
    v = (v xor (v ushr 13)) * 1274126177
    v = v xor (v ushr 16)
    return (v.toLong() and 0x7FFFFFFF) / 2147483647f
}

private fun DrawScope.flowField(f: ArtFrame) {
    val count = (120 + 440 * f.detail).toInt()
    val steps = (9 + f.complexity * 15).toInt()
    val step = min(size.width, size.height) * 0.009f
    val source = Offset(f.touch.x * size.width, f.touch.y * size.height)
    repeat(count) { i ->
        var p = Offset(f.unit(i) * size.width, f.unit(i, 1) * size.height)
        val path = Path().apply { moveTo(p.x, p.y) }
        repeat(steps) {
            val nx = p.x / size.width * 5f
            val ny = p.y / size.height * 5f
            val radial = atan2(p.y - source.y, p.x - source.x)
            val angle = sin(nx + f.t * 0.24f + f.phase) * 2f + cos(ny * 1.2f - f.t * 0.19f) * 1.8f + radial * f.chaos
            p += Offset(cos(angle), sin(angle)) * step
            path.lineTo(p.x, p.y)
        }
        drawPath(path, f.color(i, 0.22f + f.unit(i, 2) * 0.5f), style = Stroke(1f + f.unit(i, 3), cap = StrokeCap.Round))
    }
}

private fun DrawScope.phyllotaxis(f: ArtFrame) {
    val count = (200 + 1550 * f.detail).toInt()
    val center = Offset(size.width * f.touch.x, size.height * f.touch.y)
    val radius = min(size.width, size.height) * 0.43f
    val goldenAngle = 2.3999632f
    val deviation = sin(f.t * 0.18f) * 0.007f * f.chaos
    repeat(count) { i ->
        val n = i.toFloat() / count
        val angle = i * (goldenAngle + deviation) + f.t * 0.13f + f.phase
        val r = sqrt(n) * radius * (0.9f + 0.1f * sin(f.t + n * 15f))
        val jitter = (f.unit(i) - 0.5f) * f.chaos * 6f
        val p = center + Offset(cos(angle), sin(angle)) * (r + jitter)
        val dot = (1.5f + 3.5f * (1f - n)) * (1f + 0.3f * sin(f.t * 0.7f + i * 0.1f))
        drawCircle(f.color(i, 0.7f), dot, p)
    }
}

private fun DrawScope.spiralGalaxy(f: ArtFrame) {
    val count = (300 + 1500 * f.detail).toInt()
    val center = Offset(size.width * 0.5f, size.height * 0.5f)
    val radius = min(size.width, size.height) * 0.49f
    val arms = 2 + (f.complexity * 5).toInt()
    val tilt = 0.3f + f.touch.y * 0.55f
    repeat(count) { i ->
        val r = sqrt(f.unit(i)) * radius
        val n = r / radius
        val scatter = (f.unit(i, 1) - 0.5f) * (0.2f + f.chaos * 1.2f)
        val angle = i % arms * ART_TAU / arms + n * 5.8f + scatter + f.phase + f.t * (0.07f + 0.15f / (0.3f + n))
        val p = center + Offset(cos(angle) * r, sin(angle) * r * tilt)
        val color = f.color(i, 0.3f + f.unit(i, 2) * 0.7f)
        drawCircle(color, 0.7f + f.unit(i, 3) * 1.8f, p)
        if (i % 53 == 0) drawCircle(color.copy(alpha = 0.09f), 8f, p)
    }
    drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF0D0), Color(0xFFFF93D8).copy(alpha = 0.2f), Color.Transparent), center, radius * 0.2f), radius * 0.2f, center)
}

private fun DrawScope.lissajous(f: ArtFrame) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val extent = min(size.width, size.height) * 0.4f
    val loops = 2 + (f.detail * 3).toInt()
    val a = 2 + (f.complexity * 7).toInt()
    val b = a + 1
    val points = (350 + f.detail * 600).toInt()
    repeat(loops) { layer ->
        val path = Path()
        val phase = f.t * 0.32f + f.phase + layer * 0.09f + f.touch.x * PI.toFloat()
        for (i in 0..points) {
            val u = i.toFloat() / points * ART_TAU
            val warp = sin(u * 7f + f.t) * f.chaos * 0.06f
            val x = center.x + sin(a * u + phase + warp) * extent * (1f - layer * 0.03f)
            val y = center.y + sin(b * u + f.touch.y * 2f) * extent * (1f - layer * 0.03f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, f.color(layer * 75, 0.5f), style = Stroke(1.6f))
    }
}

private fun DrawScope.spirograph(f: ArtFrame) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val extent = min(size.width, size.height) * 0.43f
    val numerator = 3 + (f.complexity * 8).toInt()
    val denominator = 2 + (f.unit(81) * 4).toInt()
    val r = denominator.toFloat() / (numerator + denominator)
    val bigR = 1f
    val d = r * (0.3f + f.touch.x * 1.4f)
    val scale = extent / (bigR - r + d)
    val points = (800 + f.detail * 1400).toInt()
    val layers = 2 + (f.detail * 2).toInt()
    repeat(layers) { layer ->
        val path = Path()
        val phase = f.t * 0.18f + layer * 0.035f + f.phase
        val drift = 1f + sin(f.t * 0.33f + layer) * f.chaos * 0.05f
        for (i in 0..points) {
            val u = i.toFloat() / points * ART_TAU * denominator
            val x = (bigR - r) * cos(u + phase) + d * cos((bigR - r) / r * u - phase) * drift
            val y = (bigR - r) * sin(u + phase) - d * sin((bigR - r) / r * u - phase) * drift
            val p = center + Offset(x, y) * scale
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        drawPath(path, f.color(layer * 95, 0.6f), style = Stroke(1.1f))
    }
}

private fun DrawScope.fractalTree(f: ArtFrame) {
    val depth = (5 + f.detail * 3).toInt().coerceIn(5, 11)
    val root = Offset(size.width / 2f, size.height * 0.9f)
    val initial = min(size.width * 0.2f, size.height * 0.27f)
    val spread = 0.25f + f.touch.x * 0.75f
    fun branch(origin: Offset, length: Float, angle: Float, remaining: Int, id: Int) {
        val wind = sin(f.t * 0.9f + origin.y * 0.008f) * 0.08f
        val end = origin + Offset(cos(angle + wind), sin(angle + wind)) * length
        drawLine(f.color((depth - remaining) * 70, 0.8f), origin, end, max(0.65f, remaining * 0.8f), StrokeCap.Round)
        if (remaining > 0) {
            val irregularity = (f.unit(id) - 0.5f) * f.chaos * 0.28f
            branch(end, length * (0.66f + irregularity * 0.15f), angle - spread + irregularity, remaining - 1, id * 2 + 1)
            branch(end, length * (0.66f - irregularity * 0.15f), angle + spread + irregularity, remaining - 1, id * 2 + 2)
        } else {
            drawCircle(f.color(id, 0.3f), 2.5f + f.chaos * 2f, end)
        }
    }
    branch(root, initial, -PI.toFloat() / 2f, depth, 1)
}

private fun DrawScope.mandala(f: ArtFrame) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = min(size.width, size.height) * 0.44f
    val petals = 4 + (f.complexity * 16).toInt()
    val rings = (5 + f.detail * 7).toInt()
    val points = 480 + (f.detail * 200).toInt()
    repeat(rings) { ring ->
        val base = radius * (ring + 1f) / rings
        val phase = f.t * 0.13f * if (ring % 2 == 0) 1f else -1f
        val path = Path()
        for (i in 0..points) {
            val theta = i.toFloat() / points * ART_TAU
            val petal = cos(theta * petals + ring * 0.4f + f.t * 0.3f)
            val r = base * (0.83f + 0.15f * petal + 0.04f * f.chaos * sin(theta * petals * 3 + f.phase))
            val p = center + Offset(cos(theta + phase + f.touch.x), sin(theta + phase + f.touch.x)) * r
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        path.close()
        drawPath(path, f.color(ring * 70, 0.09f))
        drawPath(path, f.color(ring * 70, 0.7f), style = Stroke(1.2f))
    }
}

private fun DrawScope.cliffordAttractor(f: ArtFrame) {
    val count = (2000 + f.detail * 6000).toInt().coerceAtMost(20000)
    val center = Offset(size.width * 0.5f, size.height * 0.52f)
    val scale = min(size.width, size.height) * 0.22f
    val a = -1.4f + sin(f.t * 0.035f + f.phase) * f.chaos * 0.35f
    val b = 1.6f + (f.touch.x - 0.5f) * 0.7f
    val c = 1f + (f.touch.y - 0.5f) * 0.55f
    val d = 0.7f + sin(f.t * 0.03f) * f.chaos * 0.3f
    var x = 0.1f
    var y = 0.1f
    val groups = Array(4) { ArrayList<Offset>(count / 4) }
    repeat(count + 100) { i ->
        val nextX = sin(a * y) + c * cos(a * x)
        val nextY = sin(b * x) + d * cos(b * y)
        x = nextX
        y = nextY
        if (i >= 100) groups[i % 4].add(center + Offset(x, y) * scale)
    }
    groups.forEachIndexed { i, points ->
        drawPoints(points, PointMode.Points, f.color(i * 80, 0.25f), 1.8f, StrokeCap.Round)
    }
}

private fun DrawScope.interference(f: ArtFrame) {
    val columns = (40 + f.detail * 28).toInt()
    val rows = (24 + f.detail * 25).toInt()
    val s1 = Offset(size.width * f.touch.x, size.height * f.touch.y)
    val s2 = Offset(size.width * (0.67f + 0.1f * cos(f.t * 0.15f + f.phase)), size.height * 0.4f)
    val wavelength = min(size.width, size.height) * (0.04f + (1f - f.complexity) * 0.1f)
    repeat(rows) { row ->
        val path = Path()
        repeat(columns + 1) { col ->
            val p = Offset(col.toFloat() / columns * size.width, row.toFloat() / rows * size.height)
            val d1 = (p - s1).getDistance()
            val d2 = (p - s2).getDistance()
            val wave = sin(d1 / wavelength * ART_TAU - f.t * 2f) + sin(d2 / wavelength * ART_TAU - f.t * (2f + f.chaos * 0.18f))
            val y = p.y + wave * 6f
            if (col == 0) path.moveTo(p.x, y) else path.lineTo(p.x, y)
            drawCircle(f.color(row * 13 + col * 3, (0.2f + abs(wave) * 0.35f).coerceAtMost(0.9f)), 1.2f + abs(wave), Offset(p.x, y))
        }
        drawPath(path, f.color(row * 13, 0.28f), style = Stroke(0.8f))
    }
    drawCircle(LabColors.cyan.copy(alpha = 0.8f), 7f, s1, style = Stroke(1.5f))
    drawCircle(LabColors.pink.copy(alpha = 0.8f), 7f, s2, style = Stroke(1.5f))
}

private class ArtAutomaton(val width: Int, seed: Int) {
    val rows = ArrayDeque<IntArray>()
    private val random = Random(seed)
    private var generation = 0
    init {
        val first = IntArray(width)
        first[width / 2] = 1
        repeat(width / 16) { first[random.nextInt(width)] = 1 }
        rows.addLast(first)
        repeat(72) { step(0.5f) }
    }
    fun step(chaos: Float) {
        val previous = rows.last()
        // Rules 90, 30 and 110 each have a distinct, reproducible transition table.
        val rule = when {
            chaos < 0.33f -> 90
            chaos < 0.67f -> 30
            else -> 110
        }
        val next = IntArray(width) { x ->
            val pattern = previous[(x + width - 1) % width] * 4 + previous[x] * 2 + previous[(x + 1) % width]
            (rule shr pattern) and 1
        }
        // A small seeded perturbation prevents a finite periodic world from dying out.
        if (chaos > 0.9f && generation % 9 == 0) next[random.nextInt(width)] = 1
        rows.addLast(next)
        while (rows.size > 96) rows.removeFirst()
        generation++
    }
    fun seedAt(x: Float) {
        val index = (x * (width - 1)).toInt().coerceIn(0, width - 1)
        for (dx in -1..1) rows.last()[(index + dx + width) % width] = 1
    }
}

private fun DrawScope.cellularArt(automaton: ArtAutomaton, f: ArtFrame) {
    val cell = size.width / automaton.width
    val rowHeight = size.height / 96
    automaton.rows.forEachIndexed { row, cells ->
        val color = f.color(row * 5, 0.82f)
        cells.forEachIndexed { col, alive ->
            if (alive == 1) drawRect(color, Offset(col * cell, row * rowHeight), androidx.compose.ui.geometry.Size(max(1f, cell - 0.5f), max(1f, rowHeight - 0.5f)))
        }
    }
}

private fun artNoise(x: Float, y: Float, seed: Int): Float {
    val ix = floor(x).toInt()
    val iy = floor(y).toInt()
    val fx = x - ix
    val fy = y - iy
    val sx = fx * fx * (3f - 2f * fx)
    val sy = fy * fy * (3f - 2f * fy)
    fun sample(dx: Int, dy: Int) = artHash((ix + dx) * 15731 + (iy + dy) * 789221, seed)
    val top = sample(0, 0) * (1f - sx) + sample(1, 0) * sx
    val bottom = sample(0, 1) * (1f - sx) + sample(1, 1) * sx
    return top * (1f - sy) + bottom * sy
}

private fun DrawScope.terrain(f: ArtFrame) {
    val columns = (14 + f.detail * 13).toInt()
    val rows = (22 + f.detail * 20).toInt()
    val horizon = size.height * 0.32f
    val movement = f.t * 0.65f
    fun height(x: Float, z: Float): Float {
        var value = 0f
        var amplitude = 1f
        var frequency = 0.15f
        repeat(4) {
            value += (artNoise(x * frequency, z * frequency + movement * frequency, f.seed + it * 97) - 0.5f) * amplitude
            amplitude *= 0.45f + f.chaos * 0.1f
            frequency *= 2f
        }
        return value
    }
    fun project(col: Int, row: Int): Offset {
        val z = 1f + row.toFloat() / rows * 15f
        val x = (col.toFloat() / columns - 0.5f) * 18f
        val perspective = 1f / z
        val elevation = height(x, z + movement) * (25f + f.touch.y * 110f)
        return Offset(size.width / 2f + x * size.width * 0.24f * perspective, horizon + size.height * 0.64f * perspective - elevation * perspective)
    }
    for (row in rows downTo 0) {
        val path = Path()
        for (col in 0..columns) {
            val point = project(col, row)
            if (col == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y)
            if (row < rows) drawLine(f.color(row * 12, 0.25f + 0.6f * (1f - row.toFloat() / rows)), point, project(col, row + 1), 0.9f)
        }
        drawPath(path, f.color(row * 12, 0.3f + 0.6f * (1f - row.toFloat() / rows)), style = Stroke(1.2f))
    }
    val sun = Offset(size.width * (0.45f + 0.15f * f.touch.x), horizon * 0.65f)
    drawCircle(Brush.radialGradient(listOf(LabColors.pink.copy(alpha = 0.7f), LabColors.purple.copy(alpha = 0.03f)), sun, 44f), 44f, sun)
}

private fun DrawScope.kaleidoscope(f: ArtFrame) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = min(size.width, size.height) * 0.46f
    val sectors = 6 + (f.complexity * 12).toInt() * 2
    val rows = (6 + f.detail * 8).toInt()
    val angleStep = ART_TAU / sectors
    fun polar(r: Float, angle: Float) = center + Offset(cos(angle), sin(angle)) * r
    repeat(sectors) { sector ->
        val mirror = if (sector % 2 == 0) 1f else -1f
        repeat(rows) { row ->
            val r1 = radius * row / rows
            val r2 = radius * (row + 1f) / rows
            val wobble = sin(f.t * 0.7f + row * 0.6f + f.phase) * 0.2f * angleStep * f.chaos
            val a = sector * angleStep + f.t * 0.09f + f.touch.x + wobble * mirror
            val path = Path().apply {
                val p1 = polar(r1, a)
                val p2 = polar(r2, a + angleStep * 0.12f)
                val p3 = polar(r2, a + angleStep * 0.88f)
                val p4 = polar(r1, a + angleStep)
                moveTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(p3.x, p3.y)
                lineTo(p4.x, p4.y)
                close()
            }
            val color = f.color(row * 48 + (sector % 2) * 15, 0.38f + 0.18f * sin(f.t + row))
            drawPath(path, color)
            drawPath(path, color.copy(alpha = 0.9f), style = Stroke(1f))
            val bead = polar((r1 + r2) * 0.5f, a + angleStep * (0.5f + 0.3f * sin(f.t + row + f.touch.y * 4f)))
            drawCircle(f.color(row * 48 + 130, 0.8f), radius / rows * 0.12f, bead)
        }
    }
}
