package com.chaoslab.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

data class SensorVector(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f)
data class SensorOrientation(val azimuth: Float = 0f, val pitch: Float = 0f, val roll: Float = 0f)

/** The readings are Android's device coordinates: +X right, +Y up, +Z out of the screen. */
@Stable
class LabSensorState internal constructor(
    val hasAccelerometer: Boolean,
    val hasGyroscope: Boolean,
    val hasMagnetometer: Boolean,
    val hasOrientation: Boolean
) {
    var acceleration by mutableStateOf(SensorVector()); internal set
    var gyroscope by mutableStateOf(SensorVector()); internal set
    var magnetic by mutableStateOf(SensorVector()); internal set
    /** Degrees. Heading is clockwise from magnetic north, in [0, 360). */
    var orientation by mutableStateOf(SensorOrientation()); internal set
    var active by mutableStateOf(false); internal set
    var lastTimestampNanos by mutableStateOf(0L); internal set
    var orientationTimestampNanos by mutableStateOf(0L); internal set
    var sampleCount by mutableStateOf(0L); internal set
}

/** Registers real sensors only while the owning screen is resumed. No synthetic fallback readings. */
@Composable
fun rememberLabSensors(): LabSensorState {
    val context = LocalContext.current.applicationContext
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val manager = remember(context) { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val accelerometer = remember(manager) { manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) }
    val gyroscope = remember(manager) { manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) }
    val magnetic = remember(manager) { manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) }
    val rotation = remember(manager) { manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) }
    val state = remember(manager) {
        LabSensorState(accelerometer != null, gyroscope != null, magnetic != null,
            rotation != null || (accelerometer != null && magnetic != null))
    }
    DisposableEffect(manager, lifecycle, state) {
        val gravityValues = FloatArray(3)
        val magneticValues = FloatArray(3)
        val rotationMatrix = FloatArray(9)
        val angles = FloatArray(3)
        var gravityReady = false
        var magneticReady = false
        var registered = false
        fun publishOrientation(timestamp: Long) {
            SensorManager.getOrientation(rotationMatrix, angles)
            val degrees = (180.0 / Math.PI).toFloat()
            state.orientation = SensorOrientation(
                (angles[0] * degrees + 360f) % 360f,
                angles[1] * degrees,
                angles[2] * degrees
            )
            state.orientationTimestampNanos = timestamp
        }
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (event.values.size < 3) return
                val vector = SensorVector(event.values[0], event.values[1], event.values[2])
                when (event.sensor.type) {
                    Sensor.TYPE_ACCELEROMETER -> {
                        state.acceleration = vector
                        // Low-pass only the orientation estimate; the displayed accelerometer remains raw.
                        for (i in 0..2) gravityValues[i] = if (gravityReady) gravityValues[i] * 0.84f + event.values[i] * 0.16f else event.values[i]
                        gravityReady = true
                    }
                    Sensor.TYPE_GYROSCOPE -> state.gyroscope = vector
                    Sensor.TYPE_MAGNETIC_FIELD -> {
                        state.magnetic = vector
                        event.values.copyInto(magneticValues, endIndex = 3)
                        magneticReady = true
                    }
                    Sensor.TYPE_ROTATION_VECTOR -> {
                        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                        publishOrientation(event.timestamp)
                    }
                }
                if (rotation == null && gravityReady && magneticReady &&
                    SensorManager.getRotationMatrix(rotationMatrix, null, gravityValues, magneticValues)) publishOrientation(event.timestamp)
                state.lastTimestampNanos = event.timestamp
                state.sampleCount++
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        fun start() {
            if (registered) return
            var any = false
            listOfNotNull(accelerometer, gyroscope, magnetic, rotation).forEach {
                any = manager.registerListener(listener, it, SensorManager.SENSOR_DELAY_GAME) || any
            }
            registered = true
            state.active = any
        }
        fun stop() {
            manager.unregisterListener(listener)
            registered = false
            state.active = false
        }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> start()
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP, Lifecycle.Event.ON_DESTROY -> stop()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) start()
        onDispose {
            lifecycle.removeObserver(observer)
            stop()
        }
    }
    return state
}
