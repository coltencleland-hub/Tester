package com.chaoslab.app

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.*
import kotlin.random.Random

private class ChaosBody(var x: Float, var y: Float, var vx: Float, var vy: Float, val radius: Float, val hue: Float, var life: Float, val ball: Boolean)
private class ChaosPulse(val x: Float, val y: Float, var radius: Float = 0f, var life: Float = 1f)
private val chaosEvents = listOf("Shockwave", "Gravity flip", "Neon storm", "Vortex", "Confetti", "Bouncing matter", "Chromatic ripples", "Laser rain")

@Composable
fun ChaosScreen(app: AppState) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val bodies = remember { mutableListOf<ChaosBody>() }
    val pulses = remember { mutableListOf<ChaosPulse>() }
    var width by remember { mutableFloatStateOf(1f) }
    var height by remember { mutableFloatStateOf(1f) }
    var time by remember { mutableFloatStateOf(0f) }
    var frame by remember { mutableIntStateOf(0) }
    var gravity by remember { mutableFloatStateOf(1f) }
    var energy by remember { mutableFloatStateOf(0f) }
    var eventList by remember { mutableStateOf(emptyList<Int>()) }
    var sequence by remember { mutableIntStateOf(0) }
    var intensity by remember { mutableFloatStateOf(.6f) }
    var auto by remember { mutableStateOf(false) }
    var autoClock by remember { mutableFloatStateOf(0f) }
    var paused by remember { mutableStateOf(false) }
    var tone by remember { mutableStateOf<ToneGenerator?>(null) }
    DisposableEffect(lifecycle, app.sound) {
        fun stop() { tone?.release(); tone = null }
        fun start() { if (app.sound && tone == null) tone = runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 45) }.getOrNull() }
        val observer = LifecycleEventObserver { _, event -> when(event) { Lifecycle.Event.ON_RESUME -> start(); Lifecycle.Event.ON_PAUSE -> stop(); else -> Unit } }
        lifecycle.addObserver(observer)
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) start()
        onDispose { lifecycle.removeObserver(observer); stop() }
    }
    fun unleash() {
        val rng = Random.Default
        eventList = chaosEvents.indices.shuffled(rng).take(rng.nextInt(3, 6))
        sequence++
        energy = 1f
        paused = false
        gravity = if (1 in eventList) -gravity else gravity
        val cx = width * .5f; val cy = height * .46f
        if (0 in eventList || 6 in eventList) pulses.add(ChaosPulse(cx,cy))
        bodies.forEach { b ->
            if (0 in eventList) { val dx=b.x-cx;val dy=b.y-cy;val d=sqrt(dx*dx+dy*dy).coerceAtLeast(1f);b.vx+=dx/d*600;b.vy+=dy/d*600 }
        }
        val spawn = ((90 + intensity * 280) * app.quality * app.stressMultiplier).toInt().coerceAtMost(950)
        repeat(spawn) { i ->
            val a = rng.nextFloat() * (2 * PI).toFloat()
            val v = 70 + rng.nextFloat() * (150 + intensity * 420)
            val isBall = 5 in eventList && i % 3 == 0
            bodies.add(ChaosBody(cx, cy, cos(a)*v,sin(a)*v, if(isBall) 6f+rng.nextFloat()*10 else 1.5f+rng.nextFloat()*4,
                rng.nextFloat()*360, if(isBall) 16f else 4f+rng.nextFloat()*5,isBall))
        }
        while(bodies.size > 1400) bodies.removeAt(0)
        feedback(context,app,true)
        if (app.sound) tone?.startTone(listOf(ToneGenerator.TONE_PROP_ACK, ToneGenerator.TONE_PROP_BEEP2, ToneGenerator.TONE_DTMF_3, ToneGenerator.TONE_DTMF_9).random(), 160)
    }
    SimulationLoop(paused) { rawDt ->
        val dt = rawDt * if(app.reducedMotion) .45f else 1f
        time += dt; energy = (energy - dt*.17f).coerceAtLeast(0f)
        if(auto) { autoClock += rawDt; if(autoClock > 3.5f) { autoClock = 0f; unleash() } }
        val cx=width*.5f;val cy=height*.46f
        val it=bodies.iterator()
        while(it.hasNext()) {
            val b=it.next();b.life -= dt
            if(b.life < 0) {it.remove();continue}
            if(3 in eventList && energy>0) {
                val dx=b.x-cx;val dy=b.y-cy;val d=sqrt(dx*dx+dy*dy).coerceAtLeast(20f)
                b.vx+=(-dy/d*300-dx/d*150)*dt*energy;b.vy+=(dx/d*300-dy/d*150)*dt*energy
            }
            b.vy += 220f * gravity * dt
            b.vx *= .998f;b.vy *= .998f
            b.x+=b.vx*dt;b.y+=b.vy*dt
            if(b.x < b.radius) {b.x=b.radius;b.vx=abs(b.vx)*.82f}
            if(b.x>width-b.radius) {b.x=width-b.radius;b.vx=-abs(b.vx)*.82f}
            if(b.y<b.radius) {b.y=b.radius;b.vy=abs(b.vy)*.82f}
            if(b.y>height-b.radius) {b.y=height-b.radius;b.vy=-abs(b.vy)*.8f}
        }
        // A real impulse solver for the bouncing matter event; particles remain independent.
        val balls = bodies.filter { it.ball }.take(220)
        for (i in balls.indices) for(j in i+1 until balls.size) {
            val a=balls[i];val b=balls[j];val dx=b.x-a.x;val dy=b.y-a.y;val rr=a.radius+b.radius;val d2=dx*dx+dy*dy
            if(d2 in .0001f..rr*rr) {
                val d=sqrt(d2);val nx=dx/d;val ny=dy/d;val overlap=(rr-d)*.5f
                a.x-=nx*overlap;a.y-=ny*overlap;b.x+=nx*overlap;b.y+=ny*overlap
                val relative=(b.vx-a.vx)*nx+(b.vy-a.vy)*ny
                if(relative<0) {val impulse=-relative*.85f;a.vx-=impulse*nx;a.vy-=impulse*ny;b.vx+=impulse*nx;b.vy+=impulse*ny}
            }
        }
        val p=pulses.iterator();while(p.hasNext()) {val pulse=p.next();pulse.radius+=dt*width*.7f;pulse.life-=dt*.7f;if(pulse.life<0)p.remove()}
        app.activeObjects=bodies.size+pulses.size;frame++
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxHeight < 450.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LabSurface(Modifier.fillMaxWidth().weight(1f).onSizeChanged { width=it.width.toFloat().coerceAtLeast(1f);height=it.height.toFloat().coerceAtLeast(1f) }) {
                Canvas(Modifier.fillMaxSize()) {
                    frame
                    val c=Offset(size.width*.5f,size.height*.46f)
                    drawRect(Brush.radialGradient(listOf(LabColors.cyan.copy(alpha=.025f+energy*.1f),LabColors.panel),c,size.maxDimension*.65f))
                    for(i in 0..6) {val r=size.minDimension*(.15f+i*.085f);drawCircle(LabColors.cyan.copy(alpha=.025f+energy*.025f),r,c,style=Stroke(1f))}
                    if(2 in eventList && energy>0) repeat(18) {i -> val a=i*2.39996f+time*.6f;val r=size.minDimension*.47f;drawLine(Color.hsv((i*21f+time*40)%360,.65f,1f).copy(alpha=energy*.2f),c,c+Offset(cos(a),sin(a))*r,2f) }
                    if(7 in eventList && energy>0) repeat(20) {i -> val x=(i*size.width/20+sin(time+i)*30)%size.width;val y=(time*220+i*43)%size.height;drawLine(LabColors.cyan.copy(alpha=energy*.4f),Offset(x,y),Offset(x+8,y+55),2f) }
                    bodies.forEach { b ->
                        val color=Color.hsv((b.hue+time*10)%360,.65f,1f).copy(alpha=(b.life/2).coerceIn(0f,1f))
                        if(b.ball) {drawCircle(color.copy(alpha=.09f),b.radius*2,Offset(b.x,b.y));drawCircle(color,b.radius,Offset(b.x,b.y));drawCircle(Color.White.copy(alpha=.5f),b.radius*.25f,Offset(b.x-b.radius*.3f,b.y-b.radius*.3f))}
                        else if(4 in eventList) rotate(b.hue+time*80,Offset(b.x,b.y)) {drawRect(color,Offset(b.x,b.y),androidx.compose.ui.geometry.Size(b.radius*2,b.radius))}
                        else drawLine(color,Offset(b.x,b.y),Offset(b.x-b.vx*.018f,b.y-b.vy*.018f),b.radius,StrokeCap.Round)
                    }
                    pulses.forEach { p -> drawCircle(LabColors.cyan.copy(alpha=p.life*.8f),p.radius,Offset(p.x,p.y),style=Stroke(3f*p.life+1));if(6 in eventList) drawCircle(LabColors.pink.copy(alpha=p.life*.5f),p.radius*.9f,Offset(p.x+8,p.y),style=Stroke(2f)) }
                }
                Column(Modifier.align(Alignment.TopStart).padding(17.dp)) {
                    Text("CHANCE ENGINE", color=LabColors.cyan,fontSize=9.sp,letterSpacing=1.8.sp)
                    Text(if(sequence==0) "Waiting for your curiosity" else "Sequence %03d · ${eventList.size} events".format(sequence),color=LabColors.muted,fontSize=11.sp,modifier=Modifier.padding(top=5.dp))
                }
                val diameter = if(compact) 124.dp else 182.dp
                Box(Modifier.align(Alignment.Center).size(diameter).border(1.dp,LabColors.cyan.copy(alpha=.45f),CircleShape).padding(7.dp)
                    .clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF274E45),Color(0xFF132C28))))
                    .clickable { unleash() }, contentAlignment=Alignment.Center) {
                    Column(horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(if(compact) 5.dp else 11.dp)) {
                        Glyph("bolt",LabColors.cyan,Modifier.size(if(compact) 29.dp else 40.dp))
                        Text("UNLEASH\nCHAOS",color=LabColors.cyan,fontSize=if(compact) 15.sp else 21.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center,letterSpacing=2.sp,lineHeight=if(compact) 19.sp else 27.sp)
                        Text("TAP TO IGNITE",color=LabColors.cyan.copy(alpha=.5f),fontSize=7.sp,letterSpacing=1.5.sp)
                    }
                }
                Text(if(eventList.isEmpty()) "Particles • physics • light • sound • haptics" else eventList.joinToString(" · ") {chaosEvents[it]},
                    color=LabColors.muted,fontSize=10.sp,textAlign=TextAlign.Center,modifier=Modifier.align(Alignment.BottomCenter).padding(18.dp))
            }
            ControlPanel {
                LabSlider("Chaos intensity",intensity,{intensity=it},.1f..1f)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Row(verticalAlignment=Alignment.CenterVertically) {Switch(auto,{auto=it;autoClock=0f});Text("Autopilot",fontSize=12.sp,modifier=Modifier.padding(start=7.dp))}
                    TextButton(onClick={paused=!paused}) {Text(if(paused) "Resume" else "Pause")}
                    TextButton(onClick={bodies.clear();pulses.clear();eventList=emptyList();energy=0f;app.activeObjects=0;frame++}) {Text("Clear")}
                }
            }
        }
    }
}
