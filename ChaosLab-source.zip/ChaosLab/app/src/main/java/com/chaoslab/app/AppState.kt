package com.chaoslab.app

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.runtime.*
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.isActive

class AppState(context: Context) {
    private val prefs = context.getSharedPreferences("chaos_lab", Context.MODE_PRIVATE)
    var showFps by mutableStateOf(prefs.getBoolean("fps", false))
    var haptics by mutableStateOf(prefs.getBoolean("haptics", true))
    var sound by mutableStateOf(prefs.getBoolean("sound", true))
    var quality by mutableFloatStateOf(prefs.getFloat("quality", 0.75f).coerceIn(0.35f, 1f))
    var reducedMotion by mutableStateOf(prefs.getBoolean("reduced", false))
    var keepAwake by mutableStateOf(prefs.getBoolean("awake", true))
    var fps by mutableFloatStateOf(0f)
    var frameMs by mutableFloatStateOf(0f)
    var p95Ms by mutableFloatStateOf(0f)
    var jank by mutableIntStateOf(0)
    var activeObjects by mutableIntStateOf(0)
    var scene by mutableStateOf("home")
    var stressMultiplier by mutableIntStateOf(1)
    var cpuStress by mutableIntStateOf(0)
    var cpuChecksum = 0.0
    var heapMb by mutableFloatStateOf(0f)
    var memoryStressMb by mutableIntStateOf(0)
    private val stressAllocations = mutableListOf<ByteArray>()
    fun setMemoryStress(megabytes: Int) {
        stressAllocations.clear()
        memoryStressMb = 0
        if (megabytes > 0) {
            try {
                repeat(megabytes.coerceAtMost(32)) { stressAllocations.add(ByteArray(1024 * 1024).also { it.fill(42) }) }
                memoryStressMb = stressAllocations.size
            } catch (_: OutOfMemoryError) { stressAllocations.clear() }
        }
    }
    fun save() { prefs.edit().putBoolean("fps", showFps).putBoolean("haptics", haptics)
        .putBoolean("sound", sound).putFloat("quality", quality).putBoolean("reduced", reducedMotion)
        .putBoolean("awake", keepAwake).apply() }
}

@Composable
fun SimulationLoop(paused: Boolean = false, onFrame: (Float) -> Unit) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val latest by rememberUpdatedState(onFrame)
    LaunchedEffect(lifecycle, paused) {
        if (!paused) lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            var previous = 0L
            while (isActive) withFrameNanos { now ->
                if (previous != 0L) latest(((now - previous) / 1_000_000_000f).coerceIn(0.001f, 0.033f))
                previous = now
            }
        }
    }
}

@Composable
fun PerformanceMonitor(app: AppState) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            val samples = ArrayDeque<Float>()
            var previous = 0L
            var lastReport = 0L
            var count = 0
            var elapsed = 0f
            while (isActive) withFrameNanos { now ->
                if (previous != 0L) {
                    val ms = (now - previous) / 1_000_000f
                    samples.addLast(ms)
                    if (samples.size > 180) samples.removeFirst()
                    if (ms > 25f) app.jank++
                    elapsed += ms
                    count++
                    if (now - lastReport > 500_000_000L) {
                        app.fps = if (elapsed > 0f) count * 1000f / elapsed else 0f
                        app.frameMs = samples.average().toFloat()
                        app.p95Ms = samples.sorted()[(samples.size * 0.95).toInt().coerceAtMost(samples.size - 1)]
                        val rt = Runtime.getRuntime()
                        app.heapMb = (rt.totalMemory() - rt.freeMemory()) / 1048576f
                        count = 0; elapsed = 0f; lastReport = now
                    }
                }
                previous = now
                if (app.cpuStress > 0) {
                    var result = app.cpuChecksum
                    repeat(app.cpuStress * 1000) { i -> result = kotlin.math.sin(result + i * 0.0001) + kotlin.math.cos(result) }
                    app.cpuChecksum = result
                }
            }
        }
    }
}

fun feedback(context: Context, state: AppState, strong: Boolean = false) {
    if (!state.haptics) return
    val vibrator = if (Build.VERSION.SDK_INT >= 31) context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        else context.getSystemService(Vibrator::class.java)
    if (vibrator?.hasVibrator() == true) {
        vibrator.vibrate(VibrationEffect.createOneShot(if (strong) 70L else 12L, if (strong) 180 else 65))
    }
}
