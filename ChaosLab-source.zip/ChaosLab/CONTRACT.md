# Chaos Lab module contract

Package: `com.chaoslab.app`. Kotlin, Jetpack Compose Material3. minSdk 26, compileSdk 35. No external art. Each module writes only its named file(s).

Shared API (root-owned `LabUi.kt` and `AppState.kt`):
- `class AppState(context: Context)` persisted settings with Compose mutable properties: `showFps: Boolean`, `haptics: Boolean`, `sound: Boolean`, `quality: Float` (0.35..1), `reducedMotion: Boolean`, `keepAwake: Boolean`; telemetry `fps: Float`, `frameMs: Float`, `p95Ms: Float`, `jank: Int`, `activeObjects: Int`, `scene: String`, `stressMultiplier: Int` (1..4).
- `LabColors.bg`, `.panel`, `.cyan`, `.purple`, `.pink`, `.amber`, `.muted`, `.text` are Compose Colors.
- `@Composable fun LabSurface(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit)` clipped rounded dark bordered Box.
- `@Composable fun ControlPanel(content: @Composable ColumnScope.() -> Unit)` compact controls Column.
- `@Composable fun ChoiceChips(options: List<String>, selected: Int, onSelected: (Int) -> Unit)` horizontally scrollable compact selection buttons.
- `@Composable fun LabSlider(label: String, value: Float, onValueChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float> = 0f..1f)` labeled slider.
- `@Composable fun SimulationLoop(paused: Boolean = false, onFrame: (Float) -> Unit)` invokes onFrame(deltaSeconds) on main per frame, only when lifecycle RESUMED. Draw updates must use explicit observable frame state in own screen. reducedMotion means slower animation, not disabled capability.
- `@Composable fun PermissionGate(permission: String, title: String, explanation: String, content: @Composable () -> Unit)` requests at screen open; handles denial & permanently denied settings action; lifecycle refresh. Only Audio and Camera use it.
- `fun feedback(context: Context, state: AppState, strong: Boolean = false)` haptics.

Screens root calls, each fills available space beneath shared header; responsive Column with canvas weight(1f), controls below or scroll as required:
- `@Composable fun PhysicsScreen(app: AppState)` in PhysicsScreen.kt.
- `@Composable fun ParticleScreen(app: AppState)` in ParticleScreen.kt.
- `@Composable fun ArtScreen(app: AppState)` in ArtScreen.kt.
- `@Composable fun AudioScreen(app: AppState)` and `MotionScreen(app: AppState)` plus reusable `rememberLabSensors()` in Sensors.kt (agent defines returned data class; notify root).
- `@Composable fun CameraScreen(app: AppState)` in CameraScreen.kt.

Use meaningful working APIs, gracefully show real unavailable-hardware messages. Release all sensor/camera/audio resources on lifecycle pause and leaving screen. Do not modify build files; tell root if dependencies needed. Current planned deps: Compose BOM 2024.12.01, activity-compose 1.9.3, lifecycle-runtime-compose 2.8.7, CameraX 1.4.1, coroutines-android 1.9.0. Kotlin 2.0.21 + compose plugin, AGP 8.7.3, Gradle 8.9. Prefer core Compose primitives / Material3; icons use generated Canvas or built-in vector paths.
